# Beijing–Hangzhou Grand Canal: hydroclimatic extremes, grain transport, and coded maintenance events

## 1. Overview

This package contains regional classifications of extreme flood and drought years, annual recorded grain-transport volumes, and coded reach-level maintenance interventions used in the study of the Beijing–Hangzhou Grand Canal during 1368–1911. The regional and grain-transport workbooks retain their supplied filenames and numerical data. All five are headerless, with the first observation in Excel row 1. The three regional classification files contain 544 data rows each. All tabular content and documentation are in English or numeric form. Maintenance data are provided once, in a single Excel workbook containing the event table.

The hydroclimatic files cover the three analytical regions: Hebei, Huanghuai, and Huainan. The grain-transport files contain the available quantitative observations for the Ming and Qing periods. Grain transport is a canal-wide series of state-organized transport, not a separate regional series.

## 2. Files and temporal coverage

| File | Content | Populated worksheet | Data records | Year range |
| --- | --- | --- | ---: | --- |
| `HEBEI_DRY_WET_TABLE.xlsx` | Hebei annual extreme-year classifications | `Sheet1` | 544 | 1368–1911 |
| `HUANGHUAI_DRY_WET_TABLE.xlsx` | Huanghuai annual extreme-year classifications | `Sheet1` | 544 | 1368–1911 |
| `HUAINAN_DRY_WET_TABLE.xlsx` | Huainan annual extreme-year classifications | `Sheet1` | 544 | 1368–1911 |
| `caoyun_ming.xlsx` | Recorded Ming grain-transport volumes | `Sheet1` | 122 | 1411–1626 |
| `caoyun_qing.xlsx` | Recorded Qing grain-transport volumes | `Sheet1` | 50 | 1724–1849 |
| `coded_maintenance_events.xlsx` | Coded reach-level maintenance interventions | `events` | 290 | 1368–1907 | — |
| `README.md` | File descriptions, variable definitions, units, and reading instructions | — | — | — |

The archive contains exactly six data files, all `.xlsx` workbooks, plus this `README.md`. The three hydroclimatic workbooks each contain one worksheet. The two grain-transport workbooks also contain empty `Sheet2` and `Sheet3` worksheets; their data are entirely in `Sheet1`. The maintenance workbook contains one worksheet, `events`. Field definitions and counting rules are provided in this README.

## 3. Regional hydroclimatic files

### Structure and variables

**The three regional workbooks have no header row. Excel row 1 is the observation for 1368, and row 544 is the observation for 1911.** Read the files with `header=None`; assigning the first observation as a header would lose the year 1368. The two column names below are assigned when importing the data:

| Excel column | Suggested variable name | Meaning | Values |
| --- | --- | --- | --- |
| A | `Year` | Gregorian calendar year | Integer, 1368–1911 |
| B | `Class` | Regional extreme-year classification | `-1`, `0`, or `1` |

Classification codes:

- `1`: identified regional extreme flood year.
- `-1`: identified regional extreme drought year.
- `0`: the year does not meet either regional extreme-year criterion. It does not imply an absence of all floods or droughts, or normal conditions at every site.

The classifications were derived from the compiled site-level dry/wet grade series using the identification criteria described in the associated manuscript. Different criteria were applied to 1368–1470 and 1471–1911 to accommodate differences in the spatial availability of grades. These workbooks provide the resulting regional classifications; their `-1/0/1` codes are distinct from the underlying dry/wet grades 1–5.

### Spatial interpretation

Hebei, Huanghuai, and Huainan are fixed analytical regions defined in the study-area methods and Fig. 1. These classifications describe extreme conditions at the regional scale. They do not locate individual flooded canal reaches or identify the origin of a particular flood, breach, or river avulsion.

### Classification totals

| Region | Extreme flood years (`1`) | Extreme drought years (`-1`) | Neither extreme category (`0`) | Total years |
| --- | ---: | ---: | ---: | ---: |
| Hebei | 41 | 49 | 454 | 544 |
| Huanghuai | 61 | 31 | 452 | 544 |
| Huainan | 50 | 34 | 460 | 544 |

All annual classification cells are populated. A zero classification must be retained as a valid category, not treated as a missing value.

## 4. Grain-transport files

### Structure and variables

**The two grain-transport workbooks have no header row. Excel row 1 is the first observation and must be retained when reading the files.**

| Excel column | Suggested variable name | Meaning | Unit |
| --- | --- | --- | --- |
| A | `Year` | Gregorian calendar year of the recorded transport volume | Year |
| B | `Volume_10k_dan` | Recorded annual grain-transport volume | `10^4 dan` |

The first Ming observation is year 1411 with a value of 226. The first Qing observation is year 1724 with a value of 316.7587. Reading these workbooks with an automatically inferred header would drop these observations.

### Historical unit

`dan` is a traditional Chinese dry-capacity measure and fiscal accounting unit for grain. The numerical values are expressed in units of 10,000 dan. For example, the value 226 for 1411 represents 2,260,000 dan, or 2.26 million dan.

The historical unit is retained. Values have not been converted to tonnes or another fixed mass unit because such a conversion would depend on grain type, packing conditions, and historical administrative practice. Numerical precision is preserved as supplied.

### Sources, coverage, and missing years

The Ming grain-transport observations were compiled from the *Ming Veritable Records* (*Ming Shilu*), and the Qing observations from Qing-period archival documents, as described in the associated manuscript. Only years with explicitly reported quantitative values are present.

The observations are irregularly distributed within 1411–1626 and 1724–1849. No quantitative grain-transport observations are included for 1627–1723, and the series ends in 1849. Missing years are absent rows; they are neither assigned zero volumes nor interpolated. There are no blank year or volume cells among the supplied observations.

The recorded volumes represent a principal state-organized grain-transport function of the canal. They do not quantify all private or commercial navigation. Fiscal policies, institutions, warfare, and transport organization also influenced these volumes.

## 5. Coded maintenance-event dataset

### File and worksheet

`coded_maintenance_events.xlsx` contains one worksheet, `events`, with 290 distinct reach-level interventions and the 10 fields defined below. Excel row 1 contains the English column headers; data occupy rows 2–291. Read this workbook with `header=0`, unlike the five headerless hydroclimatic and grain-transport workbooks.

For climate–maintenance analyses, derive the annual regional flood and drought variables from the three regional workbooks and join intervention counts by `Year` and `Region`. The field definitions and counting rules below describe the maintenance table.

### Observation unit and coverage

Each event row represents one identifiable, nonroutine engineering intervention in a particular canal reach. The dataset contains 290 interventions in 207 distinct recorded years: 142 interventions in the Ming statistical period and 148 in the Qing statistical period. The included intervention years range from 1368 to 1907; annual comparisons use the full study calendar through 1911.

Maintenance accounts were drawn from veritable records, Qing-period archives, dynastic canal treatises, government river-regulation compilations, gazetteers, and privately authored historical writings, as described in the manuscript. The public event table contains the coded fields needed for the figure analyses; the compilation and classification procedures are documented in the manuscript.

Events were delineated from the documented time, reach, engineering action, and precipitating circumstance where stated. Distinct works in different reaches receive separate event IDs. Within the same reach and year, works constitute one episode unless the accounts clearly distinguish separate times and disturbance or engineering episodes. A continuous multi-year project is counted in its first documented year of implementation or implementation order. Separately authorized or implemented phases are separate events only when explicitly distinguished in the historical accounts. Multiple sources describing the same intervention do not create additional events.

The `Yellow River` reach denotes canal-related Yellow River engineering works. A mention of several affected canal reaches does not itself create several maintenance events; identifiable works in the relevant reaches are required. Regional counts describe the locations of reach-level interventions, not the number of independent documentary accounts.

### Event fields

| Field | Type | Definition and allowed values |
| --- | --- | --- |
| `Event_ID` | Text | Unique identifier of a distinct reach-level intervention. Count each ID once in the total. |
| `Year` | Integer | Gregorian year assigned to the intervention for analysis. For a continuous project, this is the first documented year of implementation or implementation order. |
| `Dynasty` | Text | `Ming` for 1368–1643; `Qing` for 1644–1911. |
| `Reach` | Text | `Tonghui Canal`, `Northern Canal`, `Southern Canal`, `Yellow River`, `Huitong Canal`, `Middle Canal`, `Inner Canal`, or `Jiangnan Canal`. |
| `Region` | Text | `Hebei`, `Huanghuai`, or `Huainan`, assigned from the engineering reach as specified below. |
| `Adaptive_type` | Text | One mutually exclusive category: `Reactive restoration`, `Proactive adjustment`, or `Mixed`. |
| `Implementation_evidence` | Text | `Implemented`: the account records work as undertaken. `Ordered implementation`: an explicit order to undertake specified works; completion is not inferred. |
| `Has_reactive` | Text | `Yes` for `Reactive restoration` and `Mixed`; otherwise `No`. Used for the reactive-component outcome. |
| `Has_proactive` | Text | `Yes` for `Proactive adjustment` and `Mixed`; otherwise `No`. Used for the proactive-component outcome. |
| `Yellow_River_context` | Text | `Direct`: works assigned to the Yellow River reach. `Mixed`: canal-reach works with Yellow River involvement in the coded account. `No`: no coded Yellow River involvement. `Unclear`: involvement is uncertain. |

The `Mixed` value in `Adaptive_type` refers to reactive and proactive components. The `Mixed` value in `Yellow_River_context` refers to Yellow River involvement in canal-reach works. These fields describe different characteristics.

### Intervention categories and regional assignments

- **Reactive restoration:** work explicitly linked to a preceding flood, drought, breach, sedimentation, structural failure, or other disruption.
- **Proactive adjustment:** channel, water-supply, or structural work without an explicitly documented preceding disruption, including preventive or anticipatory works. This category describes the documented circumstances, not proof that no earlier disturbance occurred.
- **Mixed:** an intervention containing both reactive and proactive actions.

The mutually exclusive category counts are 126 reactive-restoration, 124 proactive-adjustment, and 40 mixed interventions. In analyses of separate components, each mixed intervention contributes once to the reactive outcome and once to the proactive outcome, but only once to the total. The component outcomes overlap and must not be summed.

| Region | Assigned reaches | Included interventions |
| --- | --- | ---: |
| Hebei | Tonghui, Northern, and Southern canals | 37 |
| Huanghuai | Yellow River, Huitong Canal, and Middle Canal | 179 |
| Huainan | Inner and Jiangnan canals | 74 |

### Counting and subsets used in Figs. 4 and 5

- **Total intervention counts:** group by the relevant year, decade, region, reach, or adaptive category and count unique `Event_ID` values.
- **Figure 4:** use the mutually exclusive `Adaptive_type` categories and the reach and event-year fields. Calendar-decade summaries retain the partial decade bins containing 1368–1369 and 1910–1911.
- **Annual Figure 5 comparisons:** use all region-year rows from the climate series as the calendar, then join event counts by `Year` and `Region`. An absent event count is set to zero, meaning no included documented intervention in that region-year; it does not establish that no routine work took place.
- **Whole-corridor maintenance:** count the unique event IDs across the three regions. Whole-corridor flood and drought variables sum the number of affected regions in each year, ranging from 0 to 3.
- **Implemented subset:** retain `Implementation_evidence == "Implemented"` (204 interventions across the whole dataset). The other 86 interventions have ordered-implementation evidence.
- **Exclusion of Yellow River involvement:** retain `Yellow_River_context == "No"` only; `Direct`, `Mixed`, and `Unclear` are excluded from this subset.
- **Component-specific outcomes:** retain `Has_reactive == "Yes"` or `Has_proactive == "Yes"` in separate analyses. These contain 166 and 164 interventions, respectively, including the mixed interventions in each.
- **Dynasty-specific outcomes:** use `Dynasty` to select the Ming or Qing period. Create previous-year flood and drought terms separately within each dynasty, so the 1643–1644 pair is excluded. Models requiring previous-year values omit the first year of each dynasty.
- **Descriptive Figure 5c comparison:** aggregate the Huanghuai flood and intervention counts over the 54 complete decades from 1370–1379 through 1900–1909.

The maintenance table records documented nonroutine interventions, not the full range of routine annual upkeep. Differences in documentation and preservation can affect the observed event counts. The hydroclimatic classifications and maintenance accounts were compiled independently: the former describe regional conditions and the latter identify engineering works at particular reaches.

## 6. Aggregation and use with the study analyses

- **Annual regional extremes:** create separate flood and drought variables from `Class == 1` and `Class == -1`, respectively. Each is binary within a region and year.
- **Whole-corridor extremes:** sum the regional flood variables, or the regional drought variables, across the three regions for each year. The result ranges from 0 to 3 affected regions. The same calendar year can therefore contribute more than one region-year record.
- **Decadal pressure:** assign each year to its calendar decade using `Decade = (Year // 10) * 10`. Sum flood and drought records separately within each decade; combined hydroclimatic pressure is their sum. Regional pressure uses the relevant regional series, while whole-corridor pressure pools all three regions.
- **Complete decades:** the 54 complete decades run from 1370–1379 through 1900–1909. The partial intervals 1368–1369 and 1910–1911 are available in the annual data but are excluded from complete-decade trend analyses.
- **Grain-transport comparison:** retain observed annual values and missing-year gaps. In the current analysis, decadal transport level is the median of the available annual values, including decades containing one observation. Within-decade variability is calculated only for decades containing at least three observations. Analyse the Ming and Qing transport series separately.
- **Maintenance comparisons:** combine the relevant regional classifications with the included maintenance events using `Year` and `Region` to analyse flood–maintenance and drought–maintenance associations or compare pressure, maintenance, and transport over time. Use the `Year` field to assign events to calendar decades.

The regional hydroclimatic and grain-transport files provide inputs for Figs. 2 and 3. The maintenance events provide inputs for Fig. 4; their use with the hydroclimatic and transport series supports Figs. 5 and 6. Detailed model specifications, pressure-class definitions, and figure-specific display choices are described in the manuscript and Supplementary Information.

## 7. Reading the files in Python

The following example requires Python with `pandas` and `openpyxl`. Run it from the directory containing the extracted workbooks, or change `data_dir` to that directory.

```python
from pathlib import Path
import pandas as pd

data_dir = Path(".")
climate_files = {
    "Hebei": "HEBEI_DRY_WET_TABLE.xlsx",
    "Huanghuai": "HUANGHUAI_DRY_WET_TABLE.xlsx",
    "Huainan": "HUAINAN_DRY_WET_TABLE.xlsx",
}

regional_frames = []
for region, filename in climate_files.items():
    frame = pd.read_excel(
        data_dir / filename,
        sheet_name="Sheet1",
        header=None,
        usecols=[0, 1],
        names=["Year", "Class"],
    )
    frame["Year"] = frame["Year"].astype(int)
    frame["Class"] = frame["Class"].astype(int)
    frame["Region"] = region
    frame["Flood"] = frame["Class"].eq(1).astype(int)
    frame["Drought"] = frame["Class"].eq(-1).astype(int)
    regional_frames.append(frame)

regional = pd.concat(regional_frames, ignore_index=True)
whole_corridor = regional.groupby("Year")[["Flood", "Drought"]].sum()

transport = {}
for dynasty, filename in {
    "Ming": "caoyun_ming.xlsx",
    "Qing": "caoyun_qing.xlsx",
}.items():
    frame = pd.read_excel(
        data_dir / filename,
        sheet_name="Sheet1",
        header=None,
        usecols=[0, 1],
        names=["Year", "Volume_10k_dan"],
    )
    frame["Year"] = frame["Year"].astype(int)
    frame["Dynasty"] = dynasty
    transport[dynasty] = frame

# Read the single maintenance table (English headers in row 1).
events = pd.read_excel(
    data_dir / "coded_maintenance_events.xlsx",
    sheet_name="events",
    header=0,
)
events["Year"] = events["Year"].astype(int)

# Join counts to the complete regional calendar, including zero-event years.
counts = (
    events.groupby(["Year", "Region"])["Event_ID"]
    .nunique()
    .rename("Maintenance")
    .reset_index()
)
annual = regional[["Year", "Region", "Flood", "Drought"]].merge(
    counts, on=["Year", "Region"], how="left", validate="one_to_one"
)
annual["Maintenance"] = annual["Maintenance"].fillna(0).astype(int)

assert len(regional) == 1632
assert len(transport["Ming"]) == 122
assert len(transport["Qing"]) == 50
assert len(events) == 290
assert events["Event_ID"].is_unique
assert annual["Maintenance"].sum() == 290
```

For dynasty-specific analyses, the statistical periods are 1368–1643 for the Ming and 1644–1911 for the Qing. Thus, 1644 is assigned to the Qing period.

## 8. Citation and reuse

When using these data, cite the associated research article and the dataset record in the repository. Use the citation and DOI provided by that record. Reuse terms are specified by the license selected for the repository deposit. Consult the article and Supplementary Information for the historical sources, reconstruction procedures, and interpretation of the data.
