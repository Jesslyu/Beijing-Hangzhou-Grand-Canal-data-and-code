# Changes for the reproducible code release

## Mapping from supplied files

| Supplied script | Release script |
|---|---|
| npj_Figure2.py | figure2.py |
| npj_figure2_zxg.py | autocorrelation.py |
| figure3.py | figure3.py |
| Figure4.py | figure4.py |
| Figure5.py | figure5.py |
| Figure6.py | figure6.py |
| Figure S1.py | station_availability.py |
| hanlao.py | classify_extremes.py |

`source_coverage.py` incorporates the retained source-composition and source-
restricted procedures used for Tables S7-S9. `figure2.py` also includes the
same-region, within-dynasty consecutive-year calculation for Table 2.

## Input and execution changes

- Replaced user-specific absolute paths with paths relative to the archive and
  explicit command-line options.
- Read the published headerless extreme-year workbooks without discarding the
  first data row. Required all 544 study years and preserved the distinction
  between missing values and an observed classification code of zero.
- Used the public English maintenance columns instead of internal workbook
  review columns. Verified that selecting Implemented records yields the same
  subset as the supplied implementation-selection flag.
- Kept grain-transport inputs unchanged and used strict numeric validation.
- Added station-grade and source-category CSV inputs needed for the retained
  supplementary analyses; no historical documentary passages are included.
- Generalized the extreme-year classifier from one region to all three regions.
  Removed the unused 30-year frequency plot. Unavailable grades are excluded
  from classification denominators, and the redundant later-period 60 percent
  screening condition was removed without changing classifications.
- Wrapped the Figure 6 workflow in a main function so importing the module no
  longer performs analysis or writes files.

## Numerical consistency changes

- Figure 3 thresholds now use the 54 complete decades specified in the final
  Methods, rather than all 56 calendar bins. For the study data the lower and
  upper thresholds remain 4 and 6, so pressure assignments and transport
  summaries are unchanged.
- Removed Pearson/Spearman correlation summaries and Benjamini-Hochberg output
  that were not used in the retained manuscript analyses. The annual PPML
  estimates, confidence intervals, and Holm adjustment are unchanged.
- Exported the eight retained same-year Huanghuai specifications explicitly as
  Table S6, with unadjusted P values marked as exploratory.
- Included the source-restricted 16-coefficient family and the three retained
  matched-source-support comparisons in Tables S8-S9.
- Added verification against the final reported table values and Figure 6
  intervals; no unreported inferential procedure was added.

## Presentation changes

- English comments, descriptions, paths, input fields, and console messages.
- Preserved the supplied main-figure layouts and used a smaller percentage font
  only where a narrow Figure 4 segment would overlap its adjacent sample count.
- Placed the Figure S1 legend below its panels and adjusted the top margin to
  keep the panel headings inside the image.
- Added headless execution, configurable PNG/PDF/SVG/TIFF export, and UTF-8
  subprocess execution. Statistical calculations do not depend on raster DPI.

## Software environment

The tested dependency versions are pinned in requirements.txt. Pandas 2.2.3 is
used with Statsmodels 0.14.5; the unpinned Pandas 3 environment encountered an
import incompatibility with that Statsmodels version. The isolated test
environment did not modify the author's existing Python installation.


## Figure 2 update (2026-10-30)

- Added full-height grey hatched bands for both incomplete boundary decades in all eight panels.
- Kept a single-row legend and removed the explanatory footer.
- Exported the final manuscript caption as Figure2_caption.txt.
- Retained the public English input readers, CLI options, numerical analysis functions, and Table 2 export unchanged.
