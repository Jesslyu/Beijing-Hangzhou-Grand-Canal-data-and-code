# Revised script
"""Figure 2 revision: raw decadal counts with Sen trends and Mann-Kendall tests.

Dependencies: numpy pandas matplotlib openpyxl
Run: python figure2.py --data-dir "folder containing the three xlsx files"
Default input: annual classification, first column year, second column code.
Codes: -1 drought, 0 non-extreme, 1 flood. Missing years are NOT zero-filled.
All 544 years are required; missing classifications are never zero-filled.
"""

from canal_common import default_data_dir, default_output_dir, read_extreme_years, parse_options
from pathlib import Path
import argparse
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from math import erfc, sqrt

REGIONS = {"Hebei":"HEBEI_DRY_WET_TABLE.xlsx", "Huanghuai":"HUANGHUAI_DRY_WET_TABLE.xlsx", "Huainan":"HUAINAN_DRY_WET_TABLE.xlsx"}
START, END = 1368, 1911
PARTIAL_FACE = "#F2F2F2"
PARTIAL_EDGE = "#888888"
PARTIAL_HATCH = "////"
FIGURE_CAPTION = 'Fig. 2 Decadal flood and drought records along the Beijing–Hangzhou Grand Canal heritage corridor during the Ming and Qing dynasties. (a–d) Extreme flood records for the whole corridor, Hebei, Huanghuai, and Huainan, respectively. (e–h) Corresponding extreme drought records. Bars show extreme-event region-year records per decade; whole-corridor counts sum the records from the three regions. Black dashed lines show Sen trends based on the 54 complete decades from 1370–1379 through 1900–1909. Panel annotations report Sen slopes, expressed as changes in records per decade per century, and Mann–Kendall P values. Full-height grey hatched bands mark the incomplete boundary decades, containing only 1368–1369 and 1910–1911 within the study period; these partial decades were excluded from trend analysis.'


def read_annual(path):
    """Read all study years without dropping the first numeric row."""
    return read_extreme_years(path)


def make_decades(annual_counts):
    # Annual values are 0/1 per region, 0..3 for the corridor (region-year counts).
    groups = annual_counts.groupby(annual_counts.index // 10 * 10)
    frame = pd.DataFrame({"count": groups.sum(), "observed_years": groups.size()})
    frame.index.name = "decade"
    frame["complete"] = frame.observed_years.eq(10)
    # The partial 1360s and 1910s are displayed but excluded from inference.
    return frame


def trend(frame):
    """Sen pairwise median slope; two-sided original MK, ties + continuity corrected.

    Standard normal approximation, no serial-dependence or multiplicity adjustment.
    Time expressed in centuries, so slopes are counts/decade per century.
    """
    full = frame.loc[frame.complete]
    years = full.index.to_numpy(dtype=float)
    y = full["count"].to_numpy(dtype=float)
    if len(y) < 12 or not np.all(np.diff(years) == 10):
        raise ValueError("Need >=12 consecutive complete decades.")
    x = (years - years.mean()) / 100.0
    i, j = np.triu_indices(len(y), k=1)
    differences = y[j] - y[i]
    slope = float(np.median(differences / (x[j] - x[i])))
    # Separate-median intercept, used only to position the descriptive Sen line.
    intercept = float(np.median(y) - slope * np.median(x))
    score = int(np.sign(differences).sum())
    n = len(y)
    _, ties = np.unique(y, return_counts=True)
    variance = float((n*(n-1)*(2*n+5) - np.sum(ties*(ties-1)*(2*ties+5))) / 18)
    z = ((score - np.sign(score)) / sqrt(variance)) if variance > 0 else 0.0
    pvalue = erfc(abs(z) / sqrt(2.0))
    result = {"n_decades": n, "first_decade": int(years[0]),
              "last_decade": int(years[-1]), "sen_slope_per_century": slope,
              "mk_S": score, "mk_var_S": variance, "mk_Z": z, "p_mk": pvalue,
              "status": "standard MK; ties and continuity corrected; no autocorrelation correction"}
    return result, slope*x + intercept


def draw(frames, stats, fitted, out):
    """Change presentation only; counts and trend calculations are unchanged."""
    plt.rcParams.update({
        "font.family": "Arial", "font.size": 24,
        "axes.titlesize": 24, "axes.labelsize": 24,
        "xtick.labelsize": 24, "ytick.labelsize": 24,
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "mathtext.fontset": "custom", "mathtext.rm": "Arial",
        "mathtext.bf": "Arial:bold",
        "hatch.linewidth": 0.8,
    })
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    fig, axes = plt.subplots(4, 2, figsize=(18, 17), sharex=True)
    for row, region in enumerate(["Whole corridor", *REGIONS]):
        # Keep a common flood/drought y-scale within each spatial unit.
        ymax = max(frames[(region, h)]["count"].max()
                   for h in ["Flood", "Drought"])
        for col, hazard in enumerate(["Flood", "Drought"]):
            ax = axes[row, col]
            key = region, hazard
            data = frames[key]
            complete = data.complete
            color = "#92cde6" if hazard == "Flood" else "#ffca65"

            # IMPORTANT: a full-height background band stays visible at count=0.
            # Bands occupy the calendar-decade bins (1360s and 1910s).
            # Their actual study-year coverage is stated in the caption.
            for decade in data.index[~complete]:
                ax.axvspan(
                    float(decade), float(decade) + 10.0,
                    ymin=0.0, ymax=1.0,
                    facecolor=PARTIAL_FACE,
                    edgecolor=PARTIAL_EDGE,
                    hatch=PARTIAL_HATCH,
                    linewidth=0.8,
                    zorder=0,
                )

            bars = ax.bar(
                data.index + 4.5, data["count"],
                width=8, color=color, zorder=2,
            )
            # Preserve the genuine count height; do not raise zero-height bars.
            for bar, ok in zip(bars, complete):
                if not ok:
                    bar.set_edgecolor(PARTIAL_EDGE)
                    bar.set_linewidth(0.8)

            ax.plot(
                data.index[complete] + 4.5, fitted[key],
                color="black", linestyle=(0, (6, 3)), lw=2, zorder=5,
            )
            result = stats.loc[
                (stats.region == region) & (stats.hazard == hazard)
            ].iloc[0]
            ptext = (f"{result.p_mk:.4f}"
                     if np.isfinite(result.p_mk) else "NA")
            ax.text(
                .02, .97,
                f"Sen slope = {result.sen_slope_per_century:.4f} / century; "
                f"MK P = {ptext}",
                transform=ax.transAxes, va="top", fontsize=24, zorder=6,
            )
            letter = "abcdefgh"[col * 4 + row]
            ax.set_title(
                rf"$\mathbf{{{letter}}}$ {region}: {hazard.lower()}",
                loc="left", pad=10,
            )
            if col == 0:
                ax.set_ylabel(
                    "Extreme-event\nregion-years / decade" if row == 0
                    else "Extreme-event years\n/ decade",
                    labelpad=12, linespacing=1.1,
                )
            upper = max(2, ymax * 1.3)
            ax.set_ylim(-0.035 * upper, upper)
            ax.set_xlim(1360, 1920)
            ax.set_xticks([1400, 1500, 1600, 1700, 1800, 1900])
            ax.spines[["top", "right"]].set_visible(False)
            ax.set_axisbelow(True)
            ax.grid(axis="y", alpha=.15)
            if row == 3:
                ax.set_xlabel("Year")

    line_handles = [
        Line2D([], [], color="black", linestyle=(0, (6, 3)), lw=2.8,
               label="Sen trend")
    ]
    square_handles = [
        Patch(facecolor="#92cde6", label="Flood count"),
        Patch(facecolor="#ffca65", label="Drought count"),
        Patch(
            facecolor=PARTIAL_FACE, edgecolor=PARTIAL_EDGE,
            hatch=PARTIAL_HATCH, label="Partial decade (excluded)",
        ),
    ]
    fig.legend(
        handles=line_handles + square_handles,
        loc="lower center", bbox_to_anchor=(.5, .018),
        ncol=4, frameon=False, fontsize=24,
        handlelength=2.5, handleheight=1,
        columnspacing=1.8, handletextpad=0.8,
    )
    fig.tight_layout(rect=(0, .075, 1, 1), h_pad=2.0)
    fig.savefig(out / "Figure2_sen_mk.png", dpi=300, facecolor="white")
    fig.savefig(out / "Figure2_sen_mk.pdf", facecolor="white")
    (out / "Figure2_caption.txt").write_text(FIGURE_CAPTION, encoding="utf-8")
    plt.close(fig)



def frequency_recurrence(annual):
    """Count consecutive extremes in the same region and dynasty."""
    rows=[]
    for hazard, code in [("Flood",1),("Drought",-1)]:
        for dynasty, start, end in [("Ming",1368,1643),("Qing",1644,1911)]:
            regional=[]
            for region, series in annual.items():
                event=series.loc[start:end].eq(code)
                n1=int(event.iloc[:-1].sum())
                n11=int(np.sum(event.iloc[:-1].to_numpy() & event.iloc[1:].to_numpy()))
                regional.append({"Region":region,"Records":int(event.sum()),"N1":n1,"N11":n11})
            corridor={"Region":"Whole corridor", **{key:sum(row[key] for row in regional) for key in ["Records","N1","N11"]}}
            for row in [corridor,*regional]:
                row.update({"Dynasty":dynasty,"Extreme_event":hazard,"Period_years":end-start+1,
                            "Mean_records_per_decade":row["Records"]/(end-start+1)*10,
                            "P11":row["N11"]/row["N1"] if row["N1"] else np.nan})
                rows.append(row)
    return pd.DataFrame(rows)

def main():
    args = parse_options(__doc__, "figure2")
    annual = {r: read_annual(args.data_dir / cn)
              for r, cn in REGIONS.items()}
    frames, fitted, rows, series = {}, {}, [], []
    for hazard, code in [("Flood", 1), ("Drought", -1)]:
        counts = {r: s.eq(code).astype(int) for r, s in annual.items()}
        counts = {"Whole corridor": pd.concat(counts, axis=1).sum(axis=1), **counts}
        for region, annual_count in counts.items():
            key = region, hazard
            frames[key] = make_decades(annual_count)
            summary, fitted[key] = trend(frames[key])
            rows.append(dict(region=region, hazard=hazard, **summary))
            series.append(frames[key].reset_index().assign(region=region, hazard=hazard))
    stats = pd.DataFrame(rows)
    # Each sequence is tested separately at alpha=0.05; no multiple-testing adjustment.
    stats["significant_0_05"] = stats.p_mk.map(
        lambda p: "not_testable" if pd.isna(p) else ("yes" if p < 0.05 else "no"))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    stats.to_csv(args.output_dir / "trend_statistics.csv", index=False, encoding="utf-8-sig")
    pd.concat(series).to_csv(args.output_dir / "decadal_counts.csv", index=False, encoding="utf-8-sig")
    settings = dict(start=START, end=END, drought_code=-1, flood_code=1,
                    event_list=False,
                    trend_period="1370-1909: 54 full calendar decades",
                    partial_decades="1368-1369 and 1910-1911 displayed, excluded from trend analysis",
                    moving_window_statistics="none",
                    inference="Sen slope; two-sided standard Mann-Kendall with tie and continuity corrections",
                    significance_level=0.05, multiple_testing_adjustment="none; each sequence tested separately",
                    caveat="Standard MK assumes independent observations; no autocorrelation correction.")
    (args.output_dir / "analysis_settings.json").write_text(json.dumps(settings, indent=2), encoding="utf-8")
    frequency_recurrence(annual).to_csv(args.output_dir / "Table_2_frequency_recurrence.csv", index=False)
    draw(frames, stats, fitted, args.output_dir)
    print(stats.to_string(index=False))
    print(f"Results saved to: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()