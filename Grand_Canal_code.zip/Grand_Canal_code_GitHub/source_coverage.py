"""Reproduce maintenance source composition and source-restricted models (S7-S9)."""
from __future__ import annotations

import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from canal_common import REGIONS, parse_options, read_maintenance_data, read_hazard_data, read_source_groups
from figure5 import build_annual_counts, fit_annual_ppml, prepare_annual_model_data, extract_term, run_primary_annual_models


def source_composition(events):
    rows=[]
    for dynasty in ["Ming","Qing","Both dynasties"]:
        period=events if dynasty=="Both dynasties" else events.loc[events.Dynasty.eq(dynasty)]
        for region in [*REGIONS,"Whole corridor"]:
            group=period if region=="Whole corridor" else period.loc[period.Region.eq(region)]
            row={"Dynasty":dynasty,"Region":region,"Events":len(group),
                 "Central_only":int(group.Source_group.eq("Central only").sum()),
                 "Central_and_gazetteer":int(group.Source_group.eq("Central and gazetteer").sum()),
                 "Gazetteer_only":int(group.Source_group.eq("Gazetteer only").sum()),
                 "Other_only":int(group.Source_group.eq("Other only").sum()),
                 "Central_attested":int(group.Central_attested.sum()),
                 "Central_attested_percent":float(group.Central_attested.mean()*100)}
            if sum(row[k] for k in ["Central_only","Central_and_gazetteer","Gazetteer_only","Other_only"])!=len(group):
                raise ValueError("Source groups must be mutually exclusive and exhaustive")
            rows.append(row)
    return pd.DataFrame(rows)


def same_year_huanghuai(events,hazards,label,keep_decades=None):
    annual=build_annual_counts(events,hazards)
    hh=annual.loc[annual.Scale.eq("Huanghuai")]
    if keep_decades is None:
        fit,use,dispersion=fit_annual_ppml(hh,"All adaptive")
    else:
        use=prepare_annual_model_data(hh,"All adaptive")
        use=use.loc[use.Decade.isin(keep_decades)].copy()
        fit=smf.glm("Outcome ~ Flood + Drought + Flood_previous_year + Drought_previous_year + C(Decade)",
                    data=use,family=sm.families.Poisson()).fit(
                    cov_type="cluster",cov_kwds={"groups":use.Decade,"use_correction":True},maxiter=300)
        if not fit.converged or not np.isfinite(fit.params).all() or not np.isfinite(fit.bse).all():
            raise RuntimeError("Matched-decade model failed")
        dispersion=float(np.sum((use.Outcome.to_numpy()-fit.mu)**2/np.clip(fit.mu,1e-12,None))/max(len(use)-len(fit.params),1))
    return extract_term(fit,"Flood",len(use),int(use.Outcome.sum()),use.Decade.nunique(),dispersion,
                        Specification=label,Source_events=int(events.Region.eq("Huanghuai").sum()),
                        P_adjustment="None; exploratory source comparison")


def main():
    args=parse_options(__doc__,"source_coverage")
    events=read_source_groups(args.data_dir,read_maintenance_data(args.data_dir))
    hazards=read_hazard_data(args.data_dir)
    source_composition(events).to_csv(args.output_dir/"Table_S7_source_composition.csv",index=False)
    central=events.loc[events.Central_attested].copy()
    full_annual=build_annual_counts(events,hazards)
    central_annual=build_annual_counts(central,hazards)
    full_results=run_primary_annual_models(full_annual)
    central_results=run_primary_annual_models(central_annual)
    hh=central_annual.loc[central_annual.Scale.eq("Huanghuai")]
    support=set(prepare_annual_model_data(hh,"All adaptive").Decade)
    rows=[same_year_huanghuai(events,hazards,"All interventions"),
          same_year_huanghuai(events,hazards,"All interventions; central-source matched decades",support),
          same_year_huanghuai(central,hazards,"Central-attested events")]
    pd.DataFrame(rows).to_csv(args.output_dir/"Table_S8_source_support_comparison.csv",index=False)
    keys=["Scale","Hazard","Timing"]
    columns=["IRR","CI_low","CI_high","P_raw","P_Holm","N_years","Outcome_total_in_model","Informative_decades"]
    full=full_results[keys+columns].rename(columns={c:"All_"+c for c in columns})
    restricted=central_results[keys+columns].rename(columns={c:"Central_"+c for c in columns})
    comparison=full.merge(restricted,on=keys,validate="one_to_one")
    comparison.to_csv(args.output_dir/"Table_S9_source_restricted_models.csv",index=False)
    print(source_composition(events).to_string(index=False))
    print(f"Source-restricted model results saved to {args.output_dir}")


if __name__=="__main__":
    main()
