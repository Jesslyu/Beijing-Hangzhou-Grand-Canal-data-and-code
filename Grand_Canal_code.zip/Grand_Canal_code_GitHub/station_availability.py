"""Create a supplementary figure of annual station-grade availability."""

from __future__ import annotations

from canal_common import configure, default_data_dir, default_output_dir, read_station_grades

from collections import Counter
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd


SOURCE = default_data_dir() / "station_grades.csv"
OUTDIR = default_output_dir("station_availability")
REGIONS = (("Hebei","Hebei",7),("Huanghuai","Huanghuai",5),("Huainan","Huainan",8))
EARLY = (1368, 1470)
LATER = (1471, 1911)
EARLY_COLOR = "#4C78A8"
LATER_COLOR = "#F2A541"


def load_counts():
    data=read_station_grades(DATA_DIR)
    counts={}
    for _,label,n_sites in REGIONS:
        group=data.loc[data.Region.eq(label)].copy()
        group["Available"]=group.Grade.isin([1,2,3,4,5]).astype(int)
        annual=group.groupby("Year").Available.sum().sort_index()
        counts[label]={"n_sites":n_sites,"annual":annual.to_dict()}
    return counts


def summarize(counts):
    records = []
    for label, item in counts.items():
        for period, (start, end) in (("1368–1470", EARLY), ("1471–1911", LATER)):
            values = [item["annual"][year] for year in range(start, end + 1)]
            frequency = Counter(values)
            for available in range(item["n_sites"] + 1):
                records.append({
                    "Region": label,
                    "Period": period,
                    "Available_stations": available,
                    "Years": frequency.get(available, 0),
                    "Percent_of_years": 100 * frequency.get(available, 0) / len(values),
                    "Period_years": len(values),
                    "Mean_available": np.mean(values),
                    "Median_available": np.median(values),
                })
    return pd.DataFrame(records)


def draw(summary):
    plt.rcParams.update({
        "font.family": "Arial",
        "font.size": 20,
        "axes.labelsize": 20,
        "axes.titlesize": 20,
        "xtick.labelsize": 20,
        "ytick.labelsize": 20,
        "legend.fontsize": 20,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })
    fig, axes = plt.subplots(1, 3, figsize=(14.4, 5.2), sharey=True)
    width = 0.38
    for panel, (axis, (_, label, n_sites)) in enumerate(zip(axes, REGIONS)):
        region = summary[summary.Region == label]
        early = region[region.Period == "1368–1470"].sort_values("Available_stations")
        later = region[region.Period == "1471–1911"].sort_values("Available_stations")
        x = np.arange(n_sites + 1)
        axis.axvspan(-0.5, 1.5, color="#D9D9D9", alpha=0.30, zorder=0)
        axis.bar(x - width / 2, early.Percent_of_years, width=width,
                 color=EARLY_COLOR, edgecolor="#2F4B63", linewidth=0.7, zorder=3)
        axis.bar(x + width / 2, later.Percent_of_years, width=width,
                 color=LATER_COLOR, edgecolor="#8C5A13", linewidth=0.7, zorder=3)
        mean_early = float(early.Mean_available.iloc[0])
        mean_later = float(later.Mean_available.iloc[0])
        under_two = int(round(sum(early.loc[early.Available_stations < 2, "Years"])))
        under_two_pct = 100 * under_two / float(early.Period_years.iloc[0])
        axis.text(0.03, 0.93,
                  f"1368–1470: mean {mean_early:.2f}/{n_sites}\n0–1 stations: {under_two} years ({under_two_pct:.1f}%)\n1471–1911: {mean_later:.2f}/{n_sites} each year",
                  transform=axis.transAxes, ha="left", va="top", fontsize=18,
                  linespacing=1.25,
                  bbox=dict(boxstyle="round,pad=0.30", facecolor="white", edgecolor="#BFBFBF", alpha=0.94))
        axis.set_title(rf"$\bf{{{chr(97 + panel)}}}$  {label}", loc="left", pad=8)
        axis.set_xticks(x)
        axis.set_xlim(-0.55, n_sites + 0.55)
        axis.set_ylim(0, 108)
        axis.set_yticks(np.arange(0, 101, 20))
        axis.grid(axis="y", color="#D9D9D9", linewidth=0.7, alpha=0.8, zorder=0)
        axis.spines["top"].set_visible(False)
        axis.spines["right"].set_visible(False)
        axis.spines["left"].set_color("#6E6E6E")
        axis.spines["bottom"].set_color("#6E6E6E")
    axes[0].set_ylabel("Percentage of years (%)")
    legend = [
        Patch(facecolor=EARLY_COLOR, edgecolor="#2F4B63", label="1368–1470 (103 years)"),
        Patch(facecolor=LATER_COLOR, edgecolor="#8C5A13", label="1471–1911 (441 years)"),
        Patch(facecolor="#D9D9D9", edgecolor="none", alpha=0.45, label="0–1 available stations"),
    ]
    fig.legend(handles=legend, loc="lower center", bbox_to_anchor=(0.5, 0.005), ncol=3,
               frameon=False, handlelength=1.4, columnspacing=2.0)
    fig.supxlabel("Number of stations with an available annual grade", y=0.16, fontsize=20)
    fig.subplots_adjust(left=0.075, right=0.99, bottom=0.29, top=0.90, wspace=0.15)
    return fig


def main():
    configure(globals(), "station_availability")
    OUTDIR.mkdir(parents=True, exist_ok=True)
    counts = load_counts()
    summary = summarize(counts)
    summary.to_csv(OUTDIR / "station_availability_distribution.csv", index=False, encoding="utf-8-sig")
    fig = draw(summary)
    fig.savefig(OUTDIR / "Supplementary_Figure_S1_station_availability.png", dpi=600, facecolor="white")
    fig.savefig(OUTDIR / "Supplementary_Figure_S1_station_availability.pdf", facecolor="white")
    fig.savefig(OUTDIR / "Supplementary_Figure_S1_station_availability.tiff", dpi=600, facecolor="white",
                pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)
    print(OUTDIR)


if __name__ == "__main__":
    main()
