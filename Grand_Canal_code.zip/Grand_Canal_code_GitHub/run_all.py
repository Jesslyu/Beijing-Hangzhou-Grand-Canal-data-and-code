"""Run every retained numerical analysis and figure from the final manuscript."""
from pathlib import Path
import argparse
import subprocess
import sys

ROOT=Path(__file__).resolve().parent
TASKS=[("classify_extremes.py","criteria"),("figure2.py","figure2"),
       ("autocorrelation.py","autocorrelation"),("figure3.py","figure3"),
       ("figure4.py","figure4"),("figure5.py","figure5"),
       ("figure6.py","figure6"),("station_availability.py","station_availability"),
       ("source_coverage.py","source_coverage")]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir",type=Path,default=ROOT/"data")
    parser.add_argument("--output-dir",type=Path,default=ROOT/"results")
    parser.add_argument("--formats",nargs="+",choices=["png","pdf","svg","tiff"],default=["png","pdf"])
    parser.add_argument("--dpi",type=int,default=300)
    args=parser.parse_args()
    for script,subdirectory in TASKS:
        command=[sys.executable,"-X","utf8",str(ROOT/script),"--data-dir",str(args.data_dir),
                 "--output-dir",str(args.output_dir/subdirectory),"--formats",*args.formats,"--dpi",str(args.dpi)]
        print(f"Running {script}",flush=True)
        subprocess.run(command,check=True)
    subprocess.run([sys.executable,"-X","utf8",str(ROOT/"verify_results.py"),"--output-dir",str(args.output_dir)],check=True)
    print("All retained analyses completed and manuscript-table checks passed.")


if __name__=="__main__":
    main()
