# -*- coding: utf-8 -*-
"""Figure 6: Huanghuai extremes/maintenance and documented corridor transport."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

from canal_common import configure, read_maintenance_data, read_extreme_years, read_transport

def main():
    configure(globals(), "figure6")
    events = read_maintenance_data(DATA)
    hh = events.loc[events.Region.eq('Huanghuai')].copy()
    hh['Year'] = pd.to_numeric(hh.Analysis_year).astype(int)
    assert len(hh) == 179

    hazard = read_extreme_years(DATA / 'HUANGHUAI_DRY_WET_TABLE.xlsx').rename('Classification').reset_index()
    annual = hazard.set_index('Year').sort_index()
    annual['Flood'] = annual.Classification.eq(1).astype(int)
    annual['Drought'] = annual.Classification.eq(-1).astype(int)
    annual['Pressure'] = annual.Flood + annual.Drought
    annual['Maintenance'] = hh.groupby('Year').Event_ID.nunique().reindex(annual.index, fill_value=0)
    annual['Decade'] = annual.index // 10 * 10
    dec = annual.groupby('Decade')[['Flood', 'Drought', 'Pressure', 'Maintenance']].sum().loc[1370:1900]
    assert len(dec) == 54
    checkpath = DATA / 'figure5_v7_outputs' / 'decadal_analysis_counts.csv'
    if checkpath.exists():
        check = pd.read_csv(checkpath).query("Scale == 'Huanghuai'").set_index('Decade')
        for our, previous in [('Flood', 'Flood'), ('Drought', 'Drought'), ('Maintenance', 'All adaptive')]:
            assert np.array_equal(dec[our].to_numpy(), check.reindex(dec.index)[previous].to_numpy()), our
    for col in ['Pressure', 'Maintenance']:
        dec[col + '_z'] = (dec[col] - dec[col].mean()) / dec[col].std(ddof=1)
    pressure_cut = dec.Pressure.quantile(2/3)
    maintenance_cut = dec.Maintenance.quantile(2/3)
    maintenance_low_cut = dec.Maintenance.quantile(1/3)
    if maintenance_low_cut != 2:
        raise ValueError('Maintenance threshold differs from the submitted analysis')
    dec['High_pressure_high_maintenance'] = (dec.Pressure > pressure_cut) & (dec.Maintenance > maintenance_cut)
    dec['High_pressure_low_maintenance'] = (dec.Pressure > pressure_cut) & (dec.Maintenance <= maintenance_low_cut)
    dec['Highlighted'] = dec.High_pressure_high_maintenance | dec.High_pressure_low_maintenance
    dec['Window_type'] = np.select([dec.High_pressure_high_maintenance, dec.High_pressure_low_maintenance], ['High pressure / high recorded maintenance', 'High pressure / low recorded maintenance'], default='Other')
    dec['Label'] = ''
    dec.loc[dec.High_pressure_high_maintenance, 'Label'] = [f'H{i+1}' for i in range(int(dec.High_pressure_high_maintenance.sum()))]
    dec.loc[dec.High_pressure_low_maintenance, 'Label'] = [f'L{i+1}' for i in range(int(dec.High_pressure_low_maintenance.sum()))]
    assert dec.High_pressure_high_maintenance.sum() == 5
    assert dec.High_pressure_low_maintenance.sum() == 3
    assert (pressure_cut, maintenance_cut) == (2, 5)

    transport_parts = []
    for dynasty, name, expected in [('Ming', 'caoyun_ming.xlsx', 122), ('Qing', 'caoyun_qing.xlsx', 50)]:
        span = (1411,1626) if dynasty == 'Ming' else (1724,1849)
        t = read_transport(TRANSPORT / name, expected, span)
        t['Year'] = t.Year.astype(int)
        assert len(t) == expected and t.Year.is_unique
        t['Dynasty'] = dynasty
        t['Decade'] = t.Year // 10 * 10
        transport_parts.append(t)
    transport = pd.concat(transport_parts, ignore_index=True)
    summary = transport.groupby('Decade').agg(Observed_years=('Year', 'size'), Median_volume=('Volume', 'median'), Mean_volume=('Volume', 'mean'))
    comparison = dec.join(summary)
    comparison['Window'] = [f'{d}\u2013{d+9}' for d in comparison.index]
    assert comparison.loc[comparison.High_pressure_low_maintenance, 'Observed_years'].isna().all()
    comparison.to_csv(OUT / 'Figure6_combined_decadal_comparison.csv', encoding='utf-8-sig')
    annual.to_csv(OUT / 'Figure6_combined_Huanghuai_annual_counts.csv', encoding='utf-8-sig')
    transport.to_csv(OUT / 'Figure6_combined_annual_transport.csv', index=False, encoding='utf-8-sig')

    plt.rcParams.update({'font.family': 'Arial', 'font.size': 24, 'axes.labelsize': 24, 'xtick.labelsize': 24, 'ytick.labelsize': 24, 'legend.fontsize': 24, 'mathtext.fontset': 'custom', 'mathtext.rm': 'Arial', 'mathtext.it': 'Arial:italic', 'mathtext.bf': 'Arial:bold', 'pdf.fonttype': 42, 'ps.fonttype': 42})
    fig, ax = plt.subplots(figsize=(24, 8.5))
    fig.subplots_adjust(left=.085, right=.89, bottom=.26, top=.9)
    ax2 = ax.twinx()
    red, blue, grey = '#B51243', '#2674C5', '#636363'
    for decade, row in dec.loc[dec.Highlighted].iterrows():
        if row.High_pressure_high_maintenance:
            ax.axvspan(decade, decade+10, color='#D8D5BD', alpha=.48, lw=0, zorder=0)
        else:
            ax.axvspan(decade, decade+10, facecolor='#DDD0EB', edgecolor='#AF9BBC', alpha=.48, hatch='///', lw=0, zorder=0)
        label_y = .88 if row.Label == 'L2' else .97
        ax.text(decade+5, label_y, row.Label, transform=ax.get_xaxis_transform(), ha='center', va='top', fontsize=24)
    ax.axhline(0, color='#D3D3D3', lw=1, zorder=0)
    ax.plot(dec.index+4.5, dec.Pressure_z, color=red, lw=2.5, zorder=3)
    ax.plot(dec.index+4.5, dec.Maintenance_z, color=blue, lw=2.5, zorder=3)
    for t in transport_parts:
        # Never connect across an unobserved calendar year.
        segment = t.Year.diff().ne(1).cumsum()
        for _, group in t.groupby(segment):
            ax2.plot(group.Year, group.Volume, color=grey, lw=1.4, alpha=.8, zorder=4)
        ax2.scatter(t.Year, t.Volume, s=24, color=grey, edgecolors='white', linewidths=.35, zorder=5)
    ax.axvline(1644, color='#777777', ls='--', lw=1.3)
    ax.text(1502, 1.04, 'Ming dynasty', transform=ax.get_xaxis_transform(), ha='center')
    ax.text(1777.5, 1.04, 'Qing dynasty', transform=ax.get_xaxis_transform(), ha='center')
    ax.set_xlim(1365, 1915)
    ax.set_ylim(-2.1, 4.1)
    ax.set_yticks([-2, -1, 0, 1, 2, 3, 4])
    ax.set_xticks(np.arange(1400, 1901, 50))
    ax.set_ylabel('Huanghuai decadal counts\n(standardized)', labelpad=15)
    ax.set_xlabel('Year')
    ax2.set_ylim(0, 800)
    ax2.set_yticks([0, 200, 400, 600, 800])
    ax2.set_ylabel('Recorded grain-transport volume\n($10^4$ dan; whole corridor)', labelpad=20, color=grey)
    ax2.tick_params(axis='y', colors=grey)
    ax.grid(axis='y', color='#ECECEC', lw=.8)
    ax.spines['top'].set_visible(False)
    ax2.spines['top'].set_visible(False)
    handles = [Line2D([], [], color=red, lw=2.5, label='Huanghuai hydroclimatic pressure'), Line2D([], [], color=blue, lw=2.5, label='Huanghuai maintenance'), Line2D([], [], color=grey, lw=1.4, marker='o', markersize=6, label='Recorded grain transport')]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.49, .09), ncol=3, frameon=False, columnspacing=1.8, handlelength=2.2)
    fig.legend(handles=[Patch(facecolor='#D8D5BD', alpha=.48, label='High pressure / high recorded maintenance'), Patch(facecolor='#DDD0EB', edgecolor='#AF9BBC', alpha=.48, hatch='///', label='High pressure / low recorded maintenance')], loc='lower center', bbox_to_anchor=(.49, .015), ncol=2, frameon=False, columnspacing=1.5)
    fig.savefig(OUT / 'Figure6_Huanghuai_transport_maintenance_combined.png', dpi=250, facecolor='white')
    fig.savefig(OUT / 'Figure6_Huanghuai_transport_maintenance_combined.pdf', facecolor='white')
    plt.close(fig)

    caption = 'Fig. 6 | Temporal comparison of hydroclimatic pressure, adaptive maintenance, and recorded grain transport. Red and blue lines show decadal hydroclimatic pressure and documented adaptive-maintenance interventions in Huanghuai, respectively. Pressure is the sum of extreme flood and drought region-year records, and maintenance counts distinct reach-level interventions, including documented implementation and explicit implementation orders. Both series cover 54 complete calendar decades from 1370–1379 to 1900–1909, are standardized separately using their means and sample standard deviations, and are plotted at decade midpoints (left axis). Grey points represent documented annual grain-transport volumes for the whole canal corridor in units of 10^4 dan (see Methods for the historical unit), with lines connecting only observations in consecutive calendar years (right axis). Missing transport years are neither interpolated nor assigned zero values. Beige shading denotes high-pressure decades with high recorded maintenance (H1, 1570–1579; H2, 1680–1689; H3, 1760–1769; H4, 1780–1789; H5, 1810–1819); purple hatched shading denotes high-pressure decades with low recorded maintenance (L1, 1630–1639; L2, 1640–1649; L3, 1850–1859). H and L denote high and low recorded maintenance, respectively; both groups meet the high-pressure criterion. High pressure and high recorded maintenance exceed the respective upper-tercile thresholds across the 54 decades, corresponding to at least three extreme-event records and six interventions. Low recorded maintenance is at or below its lower-tercile threshold, corresponding to no more than two interventions. All qualifying decades are shown, selected independently of transport values. No quantitative transport observations are available in intervals H2, L1, L2, or L3, precluding direct comparison of transport outcomes between the high- and low-maintenance groups. Intervention counts do not measure total maintenance expenditure or engineering magnitude. The dashed line marks 1644; the 1640–1649 calendar decade spans the Ming–Qing boundary. Shaded windows are descriptive and do not represent statistically identified functional phases.'
    (OUT / 'Figure6_combined_caption.txt').write_text(caption, encoding='utf-8')
    print(comparison.loc[comparison.Highlighted, ['Label', 'Window', 'Window_type', 'Pressure', 'Maintenance', 'Observed_years', 'Median_volume']].to_string(index=False))
    print('VALIDATED: 179 Huanghuai events; 54 complete decades; 122 Ming + 50 Qing annual transport observations.')

if __name__ == "__main__":
    main()
