# Input data

Place the following six study input Excel files in this directory:

- `HEBEI_DRY_WET_TABLE.xlsx`
- `HUANGHUAI_DRY_WET_TABLE.xlsx`
- `HUAINAN_DRY_WET_TABLE.xlsx`
- `caoyun_ming.xlsx`
- `caoyun_qing.xlsx`
- `coded_maintenance_events.xlsx`

The two CSV tables already included here are required for the supplementary
analyses:

- `station_grades.csv`: station grades for extreme-year identification,
  criterion sensitivity, and annual data-availability analyses.
- `maintenance_source_groups.csv`: intervention-level source categories for
  source-composition and source-restricted analyses.

See the main README for input formats, field definitions, and instructions for
running the analyses.
