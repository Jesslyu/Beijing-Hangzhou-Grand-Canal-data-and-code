# -*- coding: utf-8 -*-
"""Figure 4: types, locations, and timing of adaptive maintenance.

The script reads the public coded reach-level event dataset and produces:
  * Figure4.png (400 dpi)
  * Figure4.tiff (600 dpi, LZW compression)
  * Figure4.pdf (vector)
  * Figure4.svg (vector)
  * figure4_type_summary.csv
  * figure4_reach_summary.csv
  * figure4_decadal_summary.csv
  * Figure4_caption.txt

Each included Event_ID is counted once. Adaptive_type is treated as a
mutually exclusive descriptive classification: Reactive restoration,
Proactive adjustment, or Mixed.
"""

from __future__ import annotations

from canal_common import configure, default_data_dir, default_output_dir, read_maintenance_data

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np
import pandas as pd


# =============================================================================
# 1. Paths and settings
# =============================================================================

DATA_DIR = default_data_dir()
SOURCE = DATA_DIR / "coded_maintenance_events.xlsx"
OUTPUT_DIR = default_output_dir("figure4")

YEAR_START = 1368
YEAR_END = 1911
DYNASTY_BOUNDARY = 1644

TYPE_ORDER = [
    "Reactive restoration",
    "Proactive adjustment",
    "Mixed",
]
TYPE_LABELS = {
    "Reactive restoration": "Reactive",
    "Proactive adjustment": "Proactive",
    "Mixed": "Mixed",
}
COLORS = {
    "Reactive restoration": "#A24B5A",
    "Proactive adjustment": "#568B74",
    "Mixed": "#7B61A8",
}

REACH_MAP = {name:name for name in ["Tonghui Canal","Northern Canal","Southern Canal","Yellow River","Huitong Canal","Middle Canal","Inner Canal","Jiangnan Canal"]}
REACH_ORDER = [
    "Tonghui Canal",
    "Northern Canal",
    "Southern Canal",
    "Yellow River",
    "Huitong Canal",
    "Middle Canal",
    "Inner Canal",
    "Jiangnan Canal",
]
REACH_REGION = {
    "Tonghui Canal": "Hebei",
    "Northern Canal": "Hebei",
    "Southern Canal": "Hebei",
    "Yellow River": "Huanghuai",
    "Huitong Canal": "Huanghuai",
    "Middle Canal": "Huanghuai",
    "Inner Canal": "Huainan",
    "Jiangnan Canal": "Huainan",
}
REGION_ORDER = ["Hebei", "Huanghuai", "Huainan"]


# =============================================================================
# 2. Read and validate the final event table
# =============================================================================

def read_events():
    return read_maintenance_data(DATA_DIR)


# =============================================================================
# 3. Build descriptive summaries
# =============================================================================

def build_summaries(events: pd.DataFrame):
    period_counts = pd.DataFrame(
        {
            "Ming dynasty": events.loc[events["Dynasty"].eq("Ming"), "Adaptive_type"].value_counts(),
            "Qing dynasty": events.loc[events["Dynasty"].eq("Qing"), "Adaptive_type"].value_counts(),
            "Whole period": events["Adaptive_type"].value_counts(),
        }
    ).T.reindex(columns=TYPE_ORDER, fill_value=0)
    period_counts = period_counts.fillna(0).astype(int)
    period_shares = period_counts.div(period_counts.sum(axis=1), axis=0) * 100

    reach_counts = pd.crosstab(events["Reach"], events["Adaptive_type"])
    reach_counts = reach_counts.reindex(index=REACH_ORDER, columns=TYPE_ORDER, fill_value=0)
    reach_counts = reach_counts.astype(int)

    events = events.copy()
    events["Decade"] = events["Year"] // 10 * 10
    decades = list(range(1360, 1920, 10))
    decadal_counts = pd.crosstab(events["Decade"], events["Adaptive_type"])
    decadal_counts = decadal_counts.reindex(
        index=decades, columns=TYPE_ORDER, fill_value=0
    ).astype(int)
    decadal_counts["Total"] = decadal_counts.sum(axis=1)

    return period_counts, period_shares, reach_counts, decadal_counts


# =============================================================================
# 4. Draw Figure 4
# =============================================================================

def add_panel_title(ax, letter: str, title: str) -> None:
    ax.text(
        0.0,
        1.025,
        letter,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=22,
        fontweight="bold",
    )
    ax.text(
        0.05,
        1.025,
        title,
        transform=ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=22,
    )


def draw_figure(
    period_counts: pd.DataFrame,
    period_shares: pd.DataFrame,
    reach_counts: pd.DataFrame,
    decadal_counts: pd.DataFrame,
) -> None:
    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 22,
            "axes.titlesize": 22,
            "axes.labelsize": 22,
            "xtick.labelsize": 22,
            "ytick.labelsize": 22,
            "legend.fontsize": 22,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    fig = plt.figure(figsize=(23.5, 18.0))
    grid = fig.add_gridspec(
        2,
        2,
        left=0.145,
        right=0.985,
        bottom=0.105,
        top=0.965,
        wspace=0.43,
        hspace=0.40,
        height_ratios=[0.92, 1.18],
    )

    # ---------------------------------------------------------------- panel a
    ax = fig.add_subplot(grid[0, 0])
    periods = ["Ming dynasty", "Qing dynasty", "Whole period"]
    y_positions = np.arange(len(periods))[::-1]
    left = np.zeros(len(periods), dtype=float)

    for maintenance_type in TYPE_ORDER:
        widths = period_shares.loc[periods, maintenance_type].to_numpy()
        ax.barh(
            y_positions,
            widths,
            left=left,
            height=0.62,
            color=COLORS[maintenance_type],
            edgecolor="white",
            linewidth=1.0,
            zorder=3,
        )
        for y, segment_left, width in zip(y_positions, left, widths):
            if width >= 7:
                ax.text(
                    segment_left + width / 2,
                    y,
                    f"{width:.1f}%",
                    ha="center",
                    va="center",
                    color="white",
                    fontweight="bold",
                    fontsize=min(22, max(12, width*1.4)),
                )
        left += widths

    for y, period in zip(y_positions, periods):
        total = int(period_counts.loc[period].sum())
        ax.text(101.5, y, f"n = {total}", ha="left", va="center")

    ax.set_yticks(y_positions)
    ax.set_yticklabels(periods)
    ax.set_xlim(0, 118)
    ax.set_xticks([0, 20, 40, 60, 80, 100])
    ax.set_xlabel("Share of documented interventions (%)")
    ax.grid(axis="x", color="#E5E5E5", linewidth=1.1, zorder=0)
    add_panel_title(ax, "a", "Adaptive-maintenance composition")

    # ---------------------------------------------------------------- panel b
    ax = fig.add_subplot(grid[0, 1])
    # Leave one empty row between analytical regions so that each region name
    # can be shown once without creating a second crowded label column.
    y_positions = np.array([10, 9, 8, 6, 5, 4, 2, 1], dtype=float)
    left = np.zeros(len(REACH_ORDER), dtype=float)

    region_ranges = {
        "Hebei": (y_positions[2] - 0.46, y_positions[0] + 0.46),
        "Huanghuai": (y_positions[5] - 0.46, y_positions[3] + 0.46),
        "Huainan": (y_positions[7] - 0.46, y_positions[6] + 0.46),
    }
    for index, region in enumerate(REGION_ORDER):
        bottom, top = region_ranges[region]
        if index % 2 == 0:
            ax.axhspan(bottom, top, color="#F5F7F9", zorder=0)

    for maintenance_type in TYPE_ORDER:
        values = reach_counts.loc[REACH_ORDER, maintenance_type].to_numpy()
        ax.barh(
            y_positions,
            values,
            left=left,
            height=0.67,
            color=COLORS[maintenance_type],
            edgecolor="white",
            linewidth=0.8,
            zorder=3,
        )
        left += values

    totals = reach_counts.loc[REACH_ORDER].sum(axis=1).to_numpy()
    for y, total in zip(y_positions, totals):
        ax.text(total + 1.2, y, str(int(total)), ha="left", va="center")

    ax.set_yticks(y_positions)
    ax.set_yticklabels(REACH_ORDER)
    ax.set_ylim(0.35, 11.2)
    max_total = float(totals.max())
    ax.set_xlim(0, max_total * 1.17)
    ax.set_xlabel("Documented major interventions (n)")
    ax.grid(axis="x", color="#E5E5E5", linewidth=1.1, zorder=0)
    add_panel_title(ax, "b", "Distribution by canal reach")

    region_heading_y = {"Hebei": 10.78, "Huanghuai": 6.78, "Huainan": 2.78}
    for region in REGION_ORDER:
        ax.text(
            0.01,
            region_heading_y[region],
            region,
            transform=ax.get_yaxis_transform(),
            ha="left",
            va="center",
            fontsize=22,
            fontweight="bold",
        )

    # ---------------------------------------------------------------- panel c
    ax = fig.add_subplot(grid[1, :])
    decades = decadal_counts.index.to_numpy(dtype=int)
    x_positions = decades + 5
    bottom = np.zeros(len(decades), dtype=float)

    # The first and last calendar decades contain only 1368–1369 and
    # 1910–1911, respectively.
    ax.axvspan(
        1360,
        1370,
        facecolor="#F3F3F3",
        edgecolor="#AAAAAA",
        hatch="////",
        linewidth=0.0,
        zorder=0,
    )
    ax.axvspan(
        1910,
        1920,
        facecolor="#F3F3F3",
        edgecolor="#AAAAAA",
        hatch="////",
        linewidth=0.0,
        zorder=0,
    )

    for maintenance_type in TYPE_ORDER:
        values = decadal_counts[maintenance_type].to_numpy()
        ax.bar(
            x_positions,
            values,
            bottom=bottom,
            width=8.2,
            color=COLORS[maintenance_type],
            edgecolor="white",
            linewidth=0.6,
            zorder=3,
        )
        bottom += values

    ax.axvline(
        DYNASTY_BOUNDARY,
        color="#555555",
        linestyle="--",
        linewidth=2.0,
        zorder=4,
    )
    ymax = max(1.0, float(decadal_counts["Total"].max()) * 1.18)
    ax.set_ylim(0, ymax)
    ax.text(
        (YEAR_START + DYNASTY_BOUNDARY) / 2,
        ymax * 0.96,
        "Ming dynasty",
        ha="center",
        va="top",
        color="#555555",
    )
    ax.text(
        (DYNASTY_BOUNDARY + YEAR_END) / 2,
        ymax * 0.96,
        "Qing dynasty",
        ha="center",
        va="top",
        color="#555555",
    )
    ax.set_xlim(1358, 1920)
    ax.set_xticks([1400, 1500, 1600, 1700, 1800, 1900])
    ax.set_xlabel("Year")
    ax.set_ylabel("Documented major interventions/decade")
    ax.grid(axis="y", color="#E5E5E5", linewidth=1.1, zorder=0)
    add_panel_title(ax, "c", "Decadal timing by adaptive-maintenance type")

    legend_handles = [
        Patch(facecolor=COLORS[item], edgecolor="none", label=TYPE_LABELS[item])
        for item in TYPE_ORDER
    ]
    legend_handles.append(
        Patch(
            facecolor="#F3F3F3",
            edgecolor="#AAAAAA",
            hatch="////",
            label="Partial decade",
        )
    )
    fig.legend(
        handles=legend_handles,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.018),
        ncol=4,
        frameon=False,
        columnspacing=1.8,
        handletextpad=0.55,
    )

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(OUTPUT_DIR / "Figure4.png", dpi=400, bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "Figure4.tiff", dpi=600, bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
    fig.savefig(OUTPUT_DIR / "Figure4.pdf", bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "Figure4.svg", bbox_inches="tight")
    plt.close(fig)


# =============================================================================
# 5. Save reproducible summaries
# =============================================================================

CAPTION = """Fig. 4. Types, spatial distribution, and timing of documented major adaptive-maintenance interventions along the Beijing–Hangzhou Grand Canal, 1368–1911. (a) Mutually exclusive composition of reactive-restoration, proactive-adjustment, and mixed interventions in the Ming dynasty, Qing dynasty, and whole study period. Percentages are calculated within each bar; n denotes the number of included reach-level interventions. Mixed interventions contain both reactive and proactive components but are counted once in this descriptive classification. (b) Numbers of interventions assigned to each canal reach, stacked by adaptive-maintenance type. Each final Event_ID is assigned to one engineering reach and one analytical region, and totals are shown at the ends of the bars. (c) Decadal counts of the three adaptive-maintenance types. The dashed line marks the Ming–Qing boundary in 1644. Hatched intervals denote the partial calendar decades 1360–1369 and 1910–1919, for which the study contains only 1368–1369 and 1910–1911, respectively. Continuous multi-year projects are counted in their first implementation year, whereas explicitly separate phases are counted as distinct interventions."""


def save_summaries(
    events: pd.DataFrame,
    period_counts: pd.DataFrame,
    period_shares: pd.DataFrame,
    reach_counts: pd.DataFrame,
    decadal_counts: pd.DataFrame,
) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    type_summary = period_counts.copy()
    type_summary.columns = [f"{TYPE_LABELS[col]}_count" for col in type_summary.columns]
    for maintenance_type in TYPE_ORDER:
        type_summary[f"{TYPE_LABELS[maintenance_type]}_percent"] = period_shares[
            maintenance_type
        ].round(1)
    type_summary["Total"] = period_counts.sum(axis=1)
    type_summary.to_csv(
        OUTPUT_DIR / "figure4_type_summary.csv", encoding="utf-8-sig"
    )

    reach_summary = reach_counts.copy()
    reach_summary.insert(0, "Region", [REACH_REGION[item] for item in reach_summary.index])
    reach_summary["Total"] = reach_counts.sum(axis=1)
    reach_summary.to_csv(
        OUTPUT_DIR / "figure4_reach_summary.csv", encoding="utf-8-sig"
    )

    decadal_counts.to_csv(
        OUTPUT_DIR / "figure4_decadal_summary.csv", encoding="utf-8-sig"
    )
    (OUTPUT_DIR / "Figure4_caption.txt").write_text(CAPTION, encoding="utf-8")

    ming_n = int(events["Dynasty"].eq("Ming").sum())
    qing_n = int(events["Dynasty"].eq("Qing").sum())
    print(f"Included reach-level interventions: {events['Event_ID'].nunique()}")
    print(f"Ming: {ming_n}; Qing: {qing_n}")
    print("\nAdaptive-maintenance types:")
    print(events["Adaptive_type"].value_counts().reindex(TYPE_ORDER).to_string())
    print("\nRegions:")
    print(events["Region"].value_counts().reindex(REGION_ORDER).to_string())
    print(f"\nOutputs saved to: {OUTPUT_DIR}")


def main() -> None:
    configure(globals(), "figure4")
    events = read_events()
    period_counts, period_shares, reach_counts, decadal_counts = build_summaries(events)
    draw_figure(period_counts, period_shares, reach_counts, decadal_counts)
    save_summaries(events, period_counts, period_shares, reach_counts, decadal_counts)


if __name__ == "__main__":
    main()
