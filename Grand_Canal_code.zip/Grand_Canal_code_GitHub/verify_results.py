"""Compare computed results with the final published-precision manuscript tables."""
from pathlib import Path
import argparse
import json
import re
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent


def check(actual,expected,precision,label):
    expected=float(expected)
    if not np.isfinite(float(actual)) or abs(float(actual)-expected)>0.50001*10**(-precision):
        raise AssertionError(f"{label}: computed {actual}, manuscript {expected}")


def triple(text):
    values=re.findall(r"\d+\.\d+",text)
    if len(values)!=3:
        raise ValueError(f"Cannot read IRR and CI: {text}")
    return [float(x) for x in values]


def selected(frame,**keys):
    mask=np.ones(len(frame),dtype=bool)
    for column,value in keys.items():
        mask &= frame[column].eq(value).to_numpy()
    rows=frame.loc[mask]
    if len(rows)!=1:
        raise AssertionError(f"Expected exactly one result row: {keys}")
    return rows.iloc[0]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir",type=Path,default=ROOT/"results")
    args=parser.parse_args()
    expected=json.loads((ROOT/"expected_tables.json").read_text(encoding="utf-8"))
    read=lambda directory,name:pd.read_csv(args.output_dir/directory/name)
    checks=0
    table2=read("figure2","Table_2_frequency_recurrence.csv")
    main_reference=json.loads((ROOT/"expected_main_table2.json").read_text(encoding="utf-8"))
    for expected_row in main_reference:
        row=selected(table2,Dynasty=expected_row["Dynasty"],Region=expected_row["Region"],Extreme_event=expected_row["Extreme_event"])
        for column in ["Records","N1","N11"]:
            assert int(row[column])==int(expected_row[column]),("Table 2",column,row[column],expected_row[column])
        check(row.Mean_records_per_decade,expected_row["Mean_records_per_decade"],2,"Table 2 frequency")
        check(row.P11*100,expected_row["P11_percent"],1,"Table 2 consecutive-year percentage")
    s1=read("autocorrelation","Table_S1_autocorrelation.csv")
    for cells in expected[0]["rows"][1:]:
        row=selected(s1,region=cells[0],hazard=cells[1])
        assert int(row.n_decades)==int(cells[2])
        for column,cell in zip(["raw_acf1","residual_acf1","residual_lb5_Q","residual_lb5_p"],cells[3:7]):
            check(row[column],cell,4,f"S1 {cells[0]} {cells[1]} {column}"); checks+=1
    s2=read("criteria","Table_S2_criterion_agreement.csv")
    for cells in expected[1]["rows"][1:]:
        row=selected(s2,Region=cells[0]); assert int(row.Region_year_classifications)==int(cells[1])
        check(row.Agreement_percent,cells[2],2,"S2 agreement"); check(row.Cohen_kappa,cells[3],4,"S2 kappa"); checks+=2
    s3=read("criteria","Table_S3_uniform_criterion_trends.csv")
    for cells in expected[2]["rows"][1:]:
        row=selected(s3,Region=cells[0],Extreme_event=cells[1])
        for col,cell in zip(["Period_specific_Sen_slope","Period_specific_MK_P","Sparse_Sen_slope","Sparse_MK_P"],cells[2:]):
            check(row[col],cell,4,"S3 "+col); checks+=1
    s4=read("criteria","Table_S4_dynasty_frequencies.csv")
    for cells in expected[3]["rows"][1:]:
        row=selected(s4,Extreme_event=cells[0])
        for col,cell in zip(["Ming_Period_specific_per_decade","Ming_Sparse_per_decade","Qing_Period_specific_per_decade","Qing_Sparse_per_decade"],cells[1:]):
            check(row[col],cell,2,"S4 "+col); checks+=1
    s5=read("figure5","Table_S5_primary_annual_models.csv")
    for cells in expected[4]["rows"][1:]:
        row=selected(s5,Scale=cells[0],Hazard=cells[1],Timing=cells[2])
        for col,cell in zip(["N_years","Outcome_total_in_model","Informative_decades"],cells[3:6]):
            assert int(row[col])==int(cell),("S5",col,row[col],cell)
        for col,value in zip(["IRR","CI_low","CI_high"],triple(cells[6])):
            check(row[col],value,3,"S5 "+col); checks+=1
        check(row.P_raw,cells[7],6,"S5 raw P"); check(row.P_Holm,cells[8],6,"S5 Holm P"); checks+=2
    s6=read("figure5","Table_S6_retained_sensitivity.csv")
    labels={"All adaptive interventions":"All adaptive","Documented implementation only":"Implemented only", "Ming dynasty only":"Ming only","Qing dynasty only":"Qing only"}
    for cells in expected[5]["rows"][1:]:
        row=selected(s6,Specification=labels.get(cells[0],cells[0]))
        for col,cell in zip(["N_years","Outcome_total_in_model","Informative_decades"],cells[1:4]):
            assert int(row[col])==int(cell),("S6",col,row[col],cell)
        for col,value in zip(["IRR","CI_low","CI_high"],triple(cells[4])):
            check(row[col],value,3,"S6 "+col); checks+=1
        check(row.P_raw,cells[5],6,"S6 raw P"); checks+=1
    s7=read("source_coverage","Table_S7_source_composition.csv")
    for cells in expected[6]["rows"][1:]:
        row=selected(s7,Dynasty=cells[0],Region=cells[1])
        for col,cell in zip(["Events","Central_only","Central_and_gazetteer","Gazetteer_only","Other_only"],cells[2:7]):
            assert int(row[col])==int(cell),("S7",col,row[col],cell)
        values=re.findall(r"\d+(?:\.\d+)?",cells[7]); assert int(row.Central_attested)==int(values[0])
        check(row.Central_attested_percent,values[1],1,"S7 percent"); checks+=1
    s8=read("source_coverage","Table_S8_source_support_comparison.csv")
    for cells in expected[7]["rows"][1:]:
        row=selected(s8,Specification=cells[0]); assert int(row.Source_events)==int(cells[1]); assert int(row.Informative_decades)==int(cells[2])
        for col,value in zip(["IRR","CI_low","CI_high"],triple(cells[3])):
            check(row[col],value,3,"S8 "+col); checks+=1
        check(row.P_raw,cells[4],6,"S8 raw P"); checks+=1
    s9=read("source_coverage","Table_S9_source_restricted_models.csv")
    for cells in expected[8]["rows"][1:]:
        row=selected(s9,Scale=cells[0],Hazard=cells[1],Timing=cells[2])
        for prefix,ci,pvalues in [("All_",cells[3],cells[4]),("Central_",cells[5],cells[6])]:
            for col,value in zip(["IRR","CI_low","CI_high"],triple(ci)):
                check(row[prefix+col],value,3,"S9 "+prefix+col); checks+=1
            values=pvalues.split()
            for col,value in zip(["P_raw","P_Holm"],values):
                check(row[prefix+col],value,6,"S9 "+prefix+col); checks+=1
    intervals=read("figure6","Figure6_combined_decadal_comparison.csv")
    high=intervals.loc[intervals.High_pressure_high_maintenance.astype(bool)]
    low=intervals.loc[intervals.High_pressure_low_maintenance.astype(bool)]
    assert high.Decade.tolist()==[1570,1680,1760,1780,1810]
    assert low.Decade.tolist()==[1630,1640,1850]
    assert low.Observed_years.isna().all()
    check(selected(intervals,Decade=1570).Median_volume,312.0,1,"Figure6 H1")
    check(selected(intervals,Decade=1760).Median_volume,326.3,1,"Figure6 H3")
    check(selected(intervals,Decade=1810).Median_volume,326.0,1,"Figure6 H5")
    result={"Tables_S1_to_S9":"PASS","supplementary_numerical_checks_at_manuscript_precision":checks,
            "Table2_frequency_and_recurrence":"PASS","Table2_verified_rows":len(main_reference),
            "Figure6_intervals_and_observed_transport":"PASS"}
    args.output_dir.mkdir(parents=True,exist_ok=True)
    (args.output_dir/"verification.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))


if __name__=="__main__":
    main()
