"""Shared input readers and command-line settings for the Grand Canal study."""
from __future__ import annotations

import argparse
from pathlib import Path
import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parent
YEAR_START, YEAR_END, DYNASTY_BOUNDARY = 1368, 1911, 1644
REGIONS = ("Hebei", "Huanghuai", "Huainan")
HAZARD_NAMES = {
    "Hebei": "HEBEI_DRY_WET_TABLE.xlsx",
    "Huanghuai": "HUANGHUAI_DRY_WET_TABLE.xlsx",
    "Huainan": "HUAINAN_DRY_WET_TABLE.xlsx",
}
TYPE_ORDER = ("Reactive restoration", "Proactive adjustment", "Mixed")
REACH_REGION = {
    "Tonghui Canal": "Hebei", "Northern Canal": "Hebei", "Southern Canal": "Hebei",
    "Yellow River": "Huanghuai", "Huitong Canal": "Huanghuai", "Middle Canal": "Huanghuai",
    "Inner Canal": "Huainan", "Jiangnan Canal": "Huainan",
}


def default_data_dir():
    return PROJECT_ROOT / "data"


def default_output_dir(name):
    return PROJECT_ROOT / "results" / name


def supplemental_path(data_dir, filename):
    supplied = Path(data_dir) / filename
    return supplied if supplied.is_file() else PROJECT_ROOT / "data" / filename


def parse_options(description, name, argv=None):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--data-dir", type=Path, default=default_data_dir())
    parser.add_argument("--output-dir", type=Path, default=default_output_dir(name))
    parser.add_argument("--formats", nargs="+", choices=["png", "pdf", "svg", "tiff"], default=["png", "pdf"])
    parser.add_argument("--dpi", type=int, default=300, help="Resolution for raster figures; use 600 for print exports.")
    args = parser.parse_args(argv)
    if args.dpi <= 0:
        parser.error("--dpi must be positive")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    install_export_options(args.formats, args.dpi)
    return args


def install_export_options(formats, dpi):
    """Keep existing figure layouts while choosing formats and raster resolution."""
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib.figure import Figure
    original = getattr(Figure.savefig, "_original_savefig", Figure.savefig)
    selected = list(dict.fromkeys(formats))

    def savefig(figure, filename, *args, **kwargs):
        filename = Path(filename)
        completed = getattr(figure, "_completed_exports", set())
        for suffix in selected:
            target = filename.with_suffix("."+suffix)
            key = str(target.resolve())
            if key in completed:
                continue
            options = dict(kwargs)
            options.pop("format", None)
            options.pop("pil_kwargs", None)
            if suffix in {"png", "tiff"}:
                options["dpi"] = dpi
            if suffix == "tiff":
                options["pil_kwargs"] = {"compression": "tiff_lzw"}
            original(figure, target, *args, **options)
            completed.add(key)
        figure._completed_exports = completed
        return None

    savefig._original_savefig = original
    Figure.savefig = savefig


def configure(namespace, name):
    args = parse_options(namespace.get("__doc__", name), name)
    for key in ["DATA_DIR", "HAZARD_DIR", "TRANSPORT_DIR", "DATA", "TRANSPORT"]:
        namespace[key] = args.data_dir
    for key in ["OUTPUT_DIR", "OUTDIR", "OUT"]:
        namespace[key] = args.output_dir
    namespace["MING_FILE"] = args.data_dir / "caoyun_ming.xlsx"
    namespace["QING_FILE"] = args.data_dir / "caoyun_qing.xlsx"
    namespace["SOURCE"] = args.data_dir / "coded_maintenance_events.xlsx"
    namespace["MAINTENANCE_FILE"] = args.data_dir / "coded_maintenance_events.xlsx"
    namespace["HAZARD_FILES"] = {region: args.data_dir / filename for region, filename in HAZARD_NAMES.items()}
    return args


def _numeric_pair(path, first, second):
    """Read the two numeric columns in the public headerless Excel workbooks."""
    raw = pd.read_excel(path, header=None, usecols=[0, 1]).dropna(how="all")
    if raw.empty:
        raise ValueError(f"{Path(path).name}: empty input")
    # An English header is also accepted, but a numeric first row is never lost.
    if isinstance(raw.iloc[0, 0], str):
        if raw.iloc[0, 0].strip().lower() not in {"year", "years"}:
            raise ValueError(f"{Path(path).name}: unrecognized first row")
        raw = raw.iloc[1:].copy()
    raw.columns = [first, second]
    for field in raw:
        raw[field] = pd.to_numeric(raw[field], errors="raise")
    if raw.isna().any().any() or not np.isfinite(raw.to_numpy(dtype=float)).all():
        raise ValueError(f"{Path(path).name}: missing or nonfinite values")
    if not np.equal(raw[first], np.floor(raw[first])).all():
        raise ValueError(f"{Path(path).name}: years must be integers")
    raw[first] = raw[first].astype(int)
    if raw[first].duplicated().any():
        raise ValueError(f"{Path(path).name}: duplicate years")
    return raw.sort_values(first).reset_index(drop=True)


def read_extreme_years(path):
    raw = _numeric_pair(path, "Year", "Class")
    expected = set(range(YEAR_START, YEAR_END + 1))
    if set(raw.Year) != expected or len(raw) != len(expected):
        raise ValueError(f"{Path(path).name}: require all 544 years, 1368-1911")
    if not raw.Class.isin([-1, 0, 1]).all():
        raise ValueError(f"{Path(path).name}: expected -1=drought, 0=not identified as extreme, 1=flood")
    return raw.set_index("Year").Class.astype(int)


def read_hazard_data(data_dir):
    frames = []
    for region, filename in HAZARD_NAMES.items():
        code = read_extreme_years(Path(data_dir) / filename)
        frames.append(pd.DataFrame({"Year": code.index, "Region": region,
                                    "Flood": code.eq(1).to_numpy(dtype=int),
                                    "Drought": code.eq(-1).to_numpy(dtype=int)}))
    return pd.concat(frames, ignore_index=True)


def read_transport(path, expected_n, expected_span):
    data = _numeric_pair(path, "Year", "Volume")
    if len(data) != expected_n or (int(data.Year.min()), int(data.Year.max())) != expected_span:
        raise ValueError(f"{Path(path).name}: expected {expected_n} records spanning {expected_span}")
    if data.Volume.lt(0).any():
        raise ValueError(f"{Path(path).name}: negative transport volume")
    return data


def read_maintenance_data(data_dir):
    data = pd.read_excel(Path(data_dir) / "coded_maintenance_events.xlsx", sheet_name="events")
    required = {"Event_ID", "Year", "Dynasty", "Reach", "Region", "Adaptive_type", "Implementation_evidence", "Has_reactive", "Has_proactive", "Yellow_River_context"}
    if not required.issubset(data.columns):
        raise ValueError(f"Maintenance input is missing: {sorted(required-set(data.columns))}")
    if data[list(required)].isna().any().any():
        raise ValueError("Maintenance input has missing required values")
    for field in required - {"Year"}:
        data[field] = data[field].astype(str).str.strip()
    year = pd.to_numeric(data.Year, errors="raise")
    if not np.equal(year, np.floor(year)).all():
        raise ValueError("Intervention years must be integers")
    data["Year"] = year.astype(int)
    if not data.Year.between(YEAR_START, YEAR_END).all() or data.Event_ID.duplicated().any():
        raise ValueError("Invalid intervention years or duplicate Event_IDs")
    if not data.Adaptive_type.isin(TYPE_ORDER).all():
        raise ValueError("Unexpected maintenance category")
    if not data.Region.eq(data.Reach.map(REACH_REGION)).all():
        raise ValueError("Engineering-reach and region assignments disagree")
    expected_dynasty = np.where(data.Year.lt(DYNASTY_BOUNDARY), "Ming", "Qing")
    if not np.array_equal(data.Dynasty.to_numpy(), expected_dynasty):
        raise ValueError("Dynasty labels must use the 1644 boundary")
    if not data.Implementation_evidence.isin(["Implemented", "Ordered implementation"]).all():
        raise ValueError("Unexpected implementation status")
    for field in ["Has_reactive", "Has_proactive"]:
        data[field] = data[field].str.lower().map({"yes": "Yes", "no": "No"})
        if data[field].isna().any():
            raise ValueError(f"{field} must contain Yes or No")
    if not data.Has_reactive.eq(np.where(data.Adaptive_type.eq("Proactive adjustment"), "No", "Yes")).all():
        raise ValueError("Reactive-component flag disagrees with the maintenance category")
    if not data.Has_proactive.eq(np.where(data.Adaptive_type.eq("Reactive restoration"), "No", "Yes")).all():
        raise ValueError("Proactive-component flag disagrees with the maintenance category")
    if not data.Yellow_River_context.isin(["No", "Direct", "Mixed", "Unclear"]).all():
        raise ValueError("Unexpected Yellow River involvement category")
    # In-memory aliases preserve the original analysis functions without exposing
    # workbook review fields or changing the public dataset.
    data["Analysis_year"] = data.Year
    data["Engineering_reach"] = data.Reach
    data["Mode"] = data.Adaptive_type
    data["Implementation"] = data.Implementation_evidence
    data["Strict_analysis_use"] = np.where(data.Implementation_evidence.eq("Implemented"), "Yes", "No")
    return data.sort_values(["Year", "Reach", "Event_ID"]).reset_index(drop=True)


def read_station_grades(data_dir):
    data = pd.read_csv(supplemental_path(data_dir, "station_grades.csv"))
    if not {"Region", "Year", "Site", "Grade"}.issubset(data.columns):
        raise ValueError("Station input needs Region, Year, Site, and Grade")
    if data.isna().any().any() or data.duplicated(["Region", "Year", "Site"]).any():
        raise ValueError("Missing or duplicate station-grade records")
    if not data.Grade.isin(range(6)).all():
        raise ValueError("Grades must be 0 (unavailable) or 1-5")
    for region, n_sites in zip(REGIONS, [7, 5, 8]):
        group = data.loc[data.Region.eq(region)]
        if len(group) != 544*n_sites or group.Site.nunique() != n_sites:
            raise ValueError(f"{region}: incorrect station count or period")
        for _, site in group.groupby("Site"):
            if set(site.Year) != set(range(YEAR_START, YEAR_END+1)):
                raise ValueError(f"{region}: incomplete site-year grid")
    return data


def read_source_groups(data_dir, events):
    flags = pd.read_csv(supplemental_path(data_dir, "maintenance_source_groups.csv"))
    fields = ["Contemporary_official", "Later_central", "Gazetteer", "Central_attested"]
    if flags.Event_ID.duplicated().any() or set(flags.Event_ID) != set(events.Event_ID):
        raise ValueError("Source-category Event_IDs do not match the maintenance dataset")
    for field in fields:
        if flags[field].dtype != bool:
            flags[field] = flags[field].astype(str).str.lower().map({"true": True, "false": False})
        if flags[field].isna().any():
            raise ValueError(f"Invalid Boolean source flag: {field}")
    if not flags.Central_attested.eq(flags.Contemporary_official | flags.Later_central).all():
        raise ValueError("Central attestation disagrees with its constituent flags")
    expected = np.select([flags.Central_attested & flags.Gazetteer, flags.Central_attested, flags.Gazetteer],
                         ["Central and gazetteer", "Central only", "Gazetteer only"], default="Other only")
    if not np.array_equal(flags.Source_group.to_numpy(), expected):
        raise ValueError("Mutually exclusive source groups disagree with source flags")
    return events.merge(flags, on="Event_ID", how="left", validate="one_to_one")
