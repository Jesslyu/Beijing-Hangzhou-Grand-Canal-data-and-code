# -*- coding: utf-8 -*-
"""Figure 5: hydroclimatic extremes and documented adaptive maintenance.

Input files are read from DATA_DIR. The script produces:
  * Figure5.png (400 dpi)
  * Figure5.tiff (600 dpi, LZW compression)
  * Figure5.pdf (vector)
  * annual_primary_results.csv
  * huanghuai_sensitivity_results.csv
  * annual_analysis_counts.csv
  * decadal_analysis_counts.csv
  * Figure5_caption.txt
  * Figure5_summary.txt

Required packages:
    pandas numpy matplotlib scipy statsmodels openpyxl
"""

from __future__ import annotations

from canal_common import configure, default_data_dir, default_output_dir, read_maintenance_data, read_hazard_data

import math
import warnings
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from patsy import dmatrix
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests


# =============================================================================
# 1. Paths and settings
# =============================================================================

DATA_DIR = default_data_dir()

MAINTENANCE_FILE = DATA_DIR / "coded_maintenance_events.xlsx"

HAZARD_FILES = {
    "Hebei": DATA_DIR / "HEBEI_DRY_WET_TABLE.xlsx",
    "Huanghuai": DATA_DIR / "HUANGHUAI_DRY_WET_TABLE.xlsx",
    "Huainan": DATA_DIR / "HUAINAN_DRY_WET_TABLE.xlsx",
}

OUTPUT_DIR = default_output_dir("figure5")

YEAR_START = 1368
YEAR_END = 1911
DYNASTY_BOUNDARY = 1644
ALPHA = 0.05
FONT_SIZE = 24

REGIONS = ["Hebei", "Huanghuai", "Huainan"]
SCALES = ["Whole corridor", *REGIONS]
MAINTENANCE_TYPES = [
    "Reactive restoration",
    "Proactive adjustment",
    "Mixed",
]

COLORS = {
    "Flood": "#4A98C9",
    "Drought": "#E39A3B",
    "Reactive restoration": "#A24B5A",
    "Proactive adjustment": "#568B74",
    "Mixed": "#7B61A8",
    "Huanghuai": "#A34F5F",
    "Neutral": "#404040",
}


# =============================================================================
# 2. Read and validate the data
# =============================================================================

def check_files() -> None:
    required = [MAINTENANCE_FILE, *HAZARD_FILES.values()]
    missing = [str(path) for path in required if not path.exists()]
    if missing:
        raise FileNotFoundError(
            "The following input files were not found:\n" + "\n".join(missing)
        )


def read_events():
    return read_maintenance_data(DATA_DIR)


def read_hazards():
    return read_hazard_data(DATA_DIR)


# =============================================================================
# 3. Build annual and decadal analysis tables
# =============================================================================

def build_annual_counts(events: pd.DataFrame, hazards: pd.DataFrame) -> pd.DataFrame:
    rows = []

    # Regional counts: one row per region and year.
    for region in REGIONS:
        hz = hazards.loc[hazards["Region"].eq(region)].set_index("Year")
        regional_events = events.loc[events["Region"].eq(region)]

        for year in range(YEAR_START, YEAR_END + 1):
            observed = regional_events.loc[regional_events["Year"].eq(year)]
            row = {
                "Scale": region,
                "Year": year,
                "Flood": int(hz.at[year, "Flood"]),
                "Drought": int(hz.at[year, "Drought"]),
                "All adaptive": int(observed["Event_ID"].nunique()),
            }
            for mode in MAINTENANCE_TYPES:
                row[mode] = int(
                    observed.loc[observed["Mode"].eq(mode), "Event_ID"].nunique()
                )
            rows.append(row)

    # Whole corridor: maintenance events are counted once, while hazards are
    # pooled region-year records (range 0–3 in a year).
    corridor_hazards = hazards.groupby("Year")[["Flood", "Drought"]].sum()
    for year in range(YEAR_START, YEAR_END + 1):
        observed = events.loc[events["Year"].eq(year)]
        row = {
            "Scale": "Whole corridor",
            "Year": year,
            "Flood": int(corridor_hazards.at[year, "Flood"]),
            "Drought": int(corridor_hazards.at[year, "Drought"]),
            "All adaptive": int(observed["Event_ID"].nunique()),
        }
        for mode in MAINTENANCE_TYPES:
            row[mode] = int(
                observed.loc[observed["Mode"].eq(mode), "Event_ID"].nunique()
            )
        rows.append(row)

    annual = pd.DataFrame(rows)
    annual["Dynasty"] = np.where(
        annual["Year"] < DYNASTY_BOUNDARY, "Ming", "Qing"
    )
    return annual.sort_values(["Scale", "Year"]).reset_index(drop=True)


def build_decadal_counts(annual: pd.DataFrame) -> pd.DataFrame:
    """Use the 54 complete decades from 1370–1379 through 1900–1909."""
    data = annual.loc[annual["Year"].between(1370, 1909)].copy()
    data["Decade"] = data["Year"] // 10 * 10
    value_columns = [
        "Flood",
        "Drought",
        "All adaptive",
        *MAINTENANCE_TYPES,
    ]
    decadal = (
        data.groupby(["Scale", "Decade"], as_index=False)[value_columns]
        .sum()
        .sort_values(["Scale", "Decade"])
        .reset_index(drop=True)
    )
    expected_rows = len(SCALES) * 54
    if len(decadal) != expected_rows:
        raise ValueError(f"Expected {expected_rows} complete scale-decade rows.")
    return decadal


# =============================================================================
# 4. Annual PPML models and multiple-comparison correction
# =============================================================================

ANNUAL_TERMS = {
    "Flood": ("Flood", "Same year"),
    "Drought": ("Drought", "Same year"),
    "Flood_previous_year": ("Flood", "Following year"),
    "Drought_previous_year": ("Drought", "Following year"),
}


def prepare_annual_model_data(
    data: pd.DataFrame,
    outcome: str,
    dynasty: str | None = None,
) -> pd.DataFrame:
    use = data.sort_values("Year").copy()
    use["Dynasty"] = np.where(use["Year"] < DYNASTY_BOUNDARY, "Ming", "Qing")

    # Lags are created separately within each dynasty; the 1643/1644 pair is
    # therefore not used as a following-year comparison.
    use["Flood_previous_year"] = use.groupby("Dynasty")["Flood"].shift(1)
    use["Drought_previous_year"] = use.groupby("Dynasty")["Drought"].shift(1)
    use = use.dropna(subset=["Flood_previous_year", "Drought_previous_year"])

    if dynasty is not None:
        use = use.loc[use["Dynasty"].eq(dynasty)].copy()

    use["Decade"] = use["Year"] // 10 * 10
    use["Outcome"] = pd.to_numeric(use[outcome], errors="raise").astype(float)

    # An all-zero outcome decade contains no conditional information for a
    # Poisson model with decade fixed effects and is therefore omitted.
    informative = use.groupby("Decade")["Outcome"].sum()
    informative_decades = informative.loc[informative > 0].index
    use = use.loc[use["Decade"].isin(informative_decades)].copy()
    return use.sort_values("Year")


def fit_annual_ppml(
    data: pd.DataFrame,
    outcome: str,
    dynasty: str | None = None,
):
    use = prepare_annual_model_data(data, outcome, dynasty=dynasty)
    formula = (
        "Outcome ~ Flood + Drought + Flood_previous_year + "
        "Drought_previous_year + C(Decade)"
    )
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fit = smf.glm(
            formula=formula,
            data=use,
            family=sm.families.Poisson(),
        ).fit(
            cov_type="cluster",
            cov_kwds={"groups": use["Decade"], "use_correction": True},
            maxiter=300,
        )

    if not fit.converged:
        raise RuntimeError(f"Annual PPML did not converge for outcome {outcome}.")
    if not np.isfinite(fit.params).all() or not np.isfinite(fit.bse).all():
        raise RuntimeError(f"Annual PPML returned non-finite estimates for {outcome}.")
    for warning_item in caught:
        print(f"Model warning ({outcome}): {warning_item.message}")

    pearson_chi2 = float(
        np.sum(
            (use["Outcome"].to_numpy() - fit.mu) ** 2
            / np.clip(fit.mu, 1e-12, None)
        )
    )
    dispersion = pearson_chi2 / max(len(use) - len(fit.params), 1)
    return fit, use, dispersion


def extract_term(
    fit,
    term: str,
    n_years: int,
    outcome_total: int,
    informative_decades: int,
    dispersion: float,
    **metadata,
) -> dict:
    beta = float(fit.params[term])
    se = float(fit.bse[term])
    return {
        **metadata,
        "Term": term,
        "Beta_log_IRR": beta,
        "Robust_SE": se,
        "IRR": math.exp(beta),
        "CI_low": math.exp(beta - 1.95996398454 * se),
        "CI_high": math.exp(beta + 1.95996398454 * se),
        "P_raw": float(fit.pvalues[term]),
        "N_years": int(n_years),
        "Outcome_total_in_model": int(outcome_total),
        "Informative_decades": int(informative_decades),
        "Dispersion": float(dispersion),
    }


def run_primary_annual_models(annual: pd.DataFrame) -> pd.DataFrame:
    """Four scales × two hazards × two timing terms = 16 primary tests."""
    rows = []
    for scale in SCALES:
        data = annual.loc[annual["Scale"].eq(scale)].copy()
        fit, use, dispersion = fit_annual_ppml(data, "All adaptive")
        for term, (hazard, timing) in ANNUAL_TERMS.items():
            rows.append(
                extract_term(
                    fit,
                    term,
                    n_years=len(use),
                    outcome_total=int(use["Outcome"].sum()),
                    informative_decades=use["Decade"].nunique(),
                    dispersion=dispersion,
                    Scale=scale,
                    Hazard=hazard,
                    Timing=timing,
                    Maintenance_outcome="All adaptive",
                    Covariance="Clustered by calendar decade",
                )
            )

    results = pd.DataFrame(rows)
    results["P_Holm"] = multipletests(
        results["P_raw"].to_numpy(), alpha=ALPHA, method="holm"
    )[1]
    results["Holm_significant"] = results["P_Holm"] < ALPHA
    return results


def fit_annual_spline_hac(data: pd.DataFrame, outcome: str):
    """Full annual series with a smooth time control and HAC standard errors.

    This alternative retains zero-outcome decades and checks whether the main
    result depends on the conditional decade-fixed-effect specification.
    """
    use = data.sort_values("Year").copy()
    use["Dynasty"] = np.where(use["Year"] < DYNASTY_BOUNDARY, "Ming", "Qing")
    use["Flood_previous_year"] = use.groupby("Dynasty")["Flood"].shift(1)
    use["Drought_previous_year"] = use.groupby("Dynasty")["Drought"].shift(1)
    use = use.dropna(subset=["Flood_previous_year", "Drought_previous_year"])
    use["Outcome"] = pd.to_numeric(use[outcome], errors="raise").astype(float)
    use["Qing"] = (use["Year"] >= DYNASTY_BOUNDARY).astype(int)
    use["Decade"] = use["Year"] // 10 * 10

    spline = dmatrix(
        "bs(year, df=6, degree=3, include_intercept=False)",
        {"year": use["Year"].astype(float)},
        return_type="dataframe",
    ).drop(columns=["Intercept"], errors="ignore")
    spline.columns = [f"Spline_{i + 1}" for i in range(spline.shape[1])]
    spline.index = use.index

    design = pd.concat(
        [
            use[
                [
                    "Flood",
                    "Drought",
                    "Flood_previous_year",
                    "Drought_previous_year",
                    "Qing",
                ]
            ],
            spline,
        ],
        axis=1,
    )
    design = sm.add_constant(design, has_constant="add").astype(float)

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fit = sm.GLM(
            use["Outcome"], design, family=sm.families.Poisson()
        ).fit(
            cov_type="HAC",
            cov_kwds={"maxlags": 10, "use_correction": True},
            maxiter=300,
        )
    if not fit.converged:
        raise RuntimeError("Annual spline PPML did not converge.")
    if not np.isfinite(fit.params).all() or not np.isfinite(fit.bse).all():
        raise RuntimeError("Annual spline PPML returned non-finite estimates.")
    for warning_item in caught:
        print(f"Spline-model warning: {warning_item.message}")

    pearson_chi2 = float(
        np.sum(
            (use["Outcome"].to_numpy() - fit.mu) ** 2
            / np.clip(fit.mu, 1e-12, None)
        )
    )
    dispersion = pearson_chi2 / max(len(use) - len(fit.params), 1)
    return fit, use, dispersion


# =============================================================================
# 5. Huanghuai sensitivity analyses
# =============================================================================

def annual_outcome_for_subset(
    hazards: pd.DataFrame,
    subset: pd.DataFrame,
) -> pd.DataFrame:
    data = hazards.loc[
        hazards["Region"].eq("Huanghuai"), ["Year", "Flood", "Drought"]
    ].copy()
    counts = subset.groupby("Year")["Event_ID"].nunique()
    data["Outcome"] = data["Year"].map(counts).fillna(0).astype(int)
    return data


def run_huanghuai_sensitivity(
    events: pd.DataFrame,
    hazards: pd.DataFrame,
) -> pd.DataFrame:
    hh = events.loc[events["Region"].eq("Huanghuai")].copy()

    specifications = {
        "All adaptive": hh,
        "Implemented only": hh.loc[hh["Strict_analysis_use"].astype(str).str.lower().eq("yes")],
        "No Yellow River involvement": hh.loc[
            hh["Yellow_River_context"].astype(str).str.strip().eq("No")
        ],
        # Classification remains mutually exclusive in descriptive summaries.
        # For component-specific association models, however, a Mixed event is
        # included once in each separate model because it contains both an
        # explicitly reactive and an explicitly proactive component.
        "Reactive component present": hh.loc[
            hh["Has_reactive"].astype(str).str.strip().str.lower().eq("yes")
        ],
        "Proactive component present": hh.loc[
            hh["Has_proactive"].astype(str).str.strip().str.lower().eq("yes")
        ],
    }

    rows = []
    for label, subset in specifications.items():
        data = annual_outcome_for_subset(hazards, subset)
        fit, use, dispersion = fit_annual_ppml(data, "Outcome")
        for term, (hazard, timing) in ANNUAL_TERMS.items():
            rows.append(
                extract_term(
                    fit,
                    term,
                    n_years=len(use),
                    outcome_total=int(use["Outcome"].sum()),
                    informative_decades=use["Decade"].nunique(),
                    dispersion=dispersion,
                    Specification=label,
                    Hazard=hazard,
                    Timing=timing,
                    Covariance="Clustered by calendar decade",
                )
            )

    # Alternative temporal control using every year and HAC covariance.
    all_hh_for_spline = annual_outcome_for_subset(hazards, hh)
    fit, use, dispersion = fit_annual_spline_hac(all_hh_for_spline, "Outcome")
    for term, (hazard, timing) in ANNUAL_TERMS.items():
        rows.append(
            extract_term(
                fit,
                term,
                n_years=len(use),
                outcome_total=int(use["Outcome"].sum()),
                informative_decades=use["Decade"].nunique(),
                dispersion=dispersion,
                Specification="Spline time control (HAC)",
                Hazard=hazard,
                Timing=timing,
                Covariance="HAC, 10-year maximum lag",
            )
        )

    # Dynasty-specific estimates use all Huanghuai adaptive-maintenance events.
    all_hh = annual_outcome_for_subset(hazards, hh)
    for dynasty in ["Ming", "Qing"]:
        fit, use, dispersion = fit_annual_ppml(
            all_hh, "Outcome", dynasty=dynasty
        )
        for term, (hazard, timing) in ANNUAL_TERMS.items():
            rows.append(
                extract_term(
                    fit,
                    term,
                    n_years=len(use),
                    outcome_total=int(use["Outcome"].sum()),
                    informative_decades=use["Decade"].nunique(),
                    dispersion=dispersion,
                    Specification=f"{dynasty} only",
                    Hazard=hazard,
                    Timing=timing,
                    Covariance="Clustered by calendar decade",
                )
            )
    return pd.DataFrame(rows)


# =============================================================================
# 6. Descriptive decadal model for panel c
# =============================================================================

def fit_huanghuai_decadal(decadal: pd.DataFrame):
    data = decadal.loc[decadal["Scale"].eq("Huanghuai")].copy()
    design = sm.add_constant(data[["Flood"]], has_constant="add")

    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fit = sm.GLM(
            data["All adaptive"].astype(float),
            design.astype(float),
            family=sm.families.Poisson(),
        ).fit(
            cov_type="HAC",
            cov_kwds={"maxlags": 1, "use_correction": True},
            maxiter=300,
        )
    if not fit.converged:
        raise RuntimeError("The descriptive Huanghuai decadal model did not converge.")
    if not np.isfinite(fit.params).all() or not np.isfinite(fit.bse).all():
        raise RuntimeError("The descriptive Huanghuai decadal model returned non-finite estimates.")
    for warning_item in caught:
        print(f"Decadal-model warning: {warning_item.message}")


    beta = float(fit.params["Flood"])
    se = float(fit.bse["Flood"])
    summary = {
        "N_complete_decades": len(data),
        "Poisson_IRR_per_flood_record": math.exp(beta),
        "Poisson_CI_low": math.exp(beta - 1.95996398454 * se),
        "Poisson_CI_high": math.exp(beta + 1.95996398454 * se),
        "Poisson_P": float(fit.pvalues["Flood"]),
    }
    return fit, data, design.columns.tolist(), summary


# =============================================================================
# 7. Draw Figure 5
# =============================================================================

def grouped_bubbles(data: pd.DataFrame) -> pd.DataFrame:
    return (
        data.groupby(["Flood", "All adaptive"], as_index=False)
        .size()
        .rename(columns={"size": "Decade_count"})
        .sort_values(["Flood", "All adaptive"])
    )


def draw_figure(
    annual: pd.DataFrame,
    primary: pd.DataFrame,
    decadal_fit,
    hh_decadal: pd.DataFrame,
    design_columns: list[str],
    decadal_summary: dict,
    sensitivity: pd.DataFrame,
) -> None:
    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": FONT_SIZE,
            "axes.titlesize": FONT_SIZE,
            "axes.labelsize": FONT_SIZE,
            "xtick.labelsize": FONT_SIZE,
            "ytick.labelsize": FONT_SIZE,
            "legend.fontsize": FONT_SIZE,
            "figure.titlesize": FONT_SIZE,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

    # Extra height leaves room for the region headings above each flood row.
    fig = plt.figure(figsize=(23.5, 19.5))
    grid = fig.add_gridspec(
        2,
        2,
        left=0.140,
        right=0.985,
        bottom=0.080,
        top=0.965,
        wspace=0.50,
        hspace=0.50,
        height_ratios=[1.18, 1.00],
    )

    def add_panel_title(ax, letter: str, title: str) -> None:
        """Place the panel letter immediately beside its title."""
        ax.text(
            0.000,
            1.025,
            letter,
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=FONT_SIZE,
            fontweight="bold",
            fontfamily="Arial",
        )
        ax.text(
            0.045,
            1.025,
            title,
            transform=ax.transAxes,
            ha="left",
            va="bottom",
            fontsize=FONT_SIZE,
            fontfamily="Arial",
        )

    # ------------------------------------------------------------------ panel a
    ax = fig.add_subplot(grid[0, 0])
    series_order = ["Flood", "Drought", *MAINTENANCE_TYPES]
    display_names = {
        "Flood": "Flood",
        "Drought": "Drought",
        "Reactive restoration": "Reactive",
        "Proactive adjustment": "Proactive",
        "Mixed": "Mixed",
    }
    markers = {
        "Flood": "|",
        "Drought": "|",
        "Reactive restoration": "o",
        "Proactive adjustment": "^",
        "Mixed": "D",
    }

    positions = {}
    ypos = 17.0
    for region in REGIONS:
        for series in series_order:
            positions[(region, series)] = ypos
            ypos -= 1.0
        ypos -= 2.1

    for region_index, region in enumerate(REGIONS):
        data = annual.loc[annual["Scale"].eq(region)]
        top = positions[(region, "Flood")] + 1.55
        bottom = positions[(region, "Mixed")] - 0.47
        if region_index % 2 == 0:
            ax.axhspan(bottom, top, color="#F5F7F9", zorder=0)

        for series in series_order:
            observed = data.loc[data[series] > 0]
            y = positions[(region, series)]
            if series in {"Flood", "Drought"}:
                ax.scatter(
                    observed["Year"],
                    np.full(len(observed), y),
                    marker=markers[series],
                    s=95,
                    linewidths=2.0,
                    color=COLORS[series],
                    zorder=3,
                )
            else:
                sizes = 42 + 28 * observed[series].to_numpy()
                ax.scatter(
                    observed["Year"],
                    np.full(len(observed), y),
                    marker=markers[series],
                    s=sizes,
                    color=COLORS[series],
                    alpha=0.78,
                    edgecolor="white",
                    linewidth=0.8,
                    zorder=3,
                )

    ax.axvline(DYNASTY_BOUNDARY, color="#666666", linestyle="--", linewidth=1.8)
    y_ticks = []
    y_labels = []
    region_tick_indices = []
    for region in REGIONS:
        region_tick_indices.append(len(y_ticks))
        y_ticks.append(positions[(region, "Flood")] + 1.2)
        y_labels.append(region)
        for series in series_order:
            y_ticks.append(positions[(region, series)])
            y_labels.append(display_names[series])
    ax.set_yticks(y_ticks)
    ax.set_yticklabels(y_labels)
    for index in region_tick_indices:
        ax.get_yticklabels()[index].set_fontweight("bold")
    ax.set_ylim(min(positions.values()) - 0.65, max(positions.values()) + 2.0)
    ax.set_xlim(1362, 1917)
    ax.set_xlabel("Year")
    ax.grid(axis="x", color="#E5E5E5", linewidth=1.1)
    add_panel_title(ax, "a", "Annual timing of extremes and interventions")
    ax.text(0.29, 0.985, "Ming", transform=ax.transAxes, ha="center", va="top", color="#555555")
    ax.text(0.76, 0.985, "Qing", transform=ax.transAxes, ha="center", va="top", color="#555555")
    ax.legend(
        handles=[
            Line2D([0], [0], marker="|", color=COLORS["Flood"], linewidth=0, markersize=16, label="Flood"),
            Line2D([0], [0], marker="|", color=COLORS["Drought"], linewidth=0, markersize=16, label="Drought"),
            Line2D([0], [0], marker="o", color=COLORS["Reactive restoration"], linewidth=0, markersize=10, label="Reactive"),
            Line2D([0], [0], marker="^", color=COLORS["Proactive adjustment"], linewidth=0, markersize=10, label="Proactive"),
            Line2D([0], [0], marker="D", color=COLORS["Mixed"], linewidth=0, markersize=9, label="Mixed"),
        ],
        loc="upper center",
        bbox_to_anchor=(0.5, -0.16),
        frameon=False,
        ncol=5,
        columnspacing=0.8,
        handletextpad=0.35,
    )

    # ------------------------------------------------------------------ panel b
    ax = fig.add_subplot(grid[0, 1])
    row_definitions = [(scale, hazard) for scale in SCALES for hazard in ["Flood", "Drought"]]
    base_y = np.arange(len(row_definitions))[::-1]
    timing_offsets = {"Same year": 0.16, "Following year": -0.16}
    timing_markers = {"Same year": "o", "Following year": "s"}

    for timing in ["Same year", "Following year"]:
        for y0, (scale, hazard) in zip(base_y, row_definitions):
            row = primary.loc[
                primary["Scale"].eq(scale)
                & primary["Hazard"].eq(hazard)
                & primary["Timing"].eq(timing)
            ].iloc[0]
            significant = bool(row["Holm_significant"])
            color = COLORS[hazard]
            ax.errorbar(
                row["IRR"],
                y0 + timing_offsets[timing],
                xerr=[
                    [row["IRR"] - row["CI_low"]],
                    [row["CI_high"] - row["IRR"]],
                ],
                fmt=timing_markers[timing],
                markersize=10.0,
                color=color,
                ecolor=color,
                elinewidth=2.0,
                capsize=4.0,
                markerfacecolor=color if significant else "white",
                markeredgewidth=2.0,
                zorder=3,
            )

    ax.axvline(1.0, color="#777777", linestyle="--", linewidth=1.8)
    ax.set_yticks(base_y)
    ax.set_yticklabels(
        [f"{scale}: {hazard.lower()}" for scale, hazard in row_definitions]
    )
    ax.set_xscale("log")
    ax.set_xlim(0.15, 12.0)
    ax.set_xticks([0.2, 0.5, 1, 2, 5, 10])
    ax.set_xticklabels(["0.2", "0.5", "1", "2", "5", "10"])
    ax.set_xlabel("Incidence-rate ratio (95% CI)")
    ax.grid(axis="x", color="#E5E5E5", linewidth=1.1)
    add_panel_title(ax, "b", "Annual PPML associations")
    ax.legend(
        handles=[
            Line2D([0], [0], marker="o", color="#555555", linewidth=0, markerfacecolor="white", label="Same year"),
            Line2D([0], [0], marker="s", color="#555555", linewidth=0, markerfacecolor="white", label="Following year"),
            Line2D([0], [0], marker="o", color="#555555", linewidth=0, markerfacecolor="#555555", label="Holm P < 0.05"),
        ],
        loc="upper center",
        bbox_to_anchor=(0.5, -0.16),
        frameon=False,
        ncol=3,
        columnspacing=0.8,
        handletextpad=0.35,
    )

    # ------------------------------------------------------------------ panel c
    ax = fig.add_subplot(grid[1, 0])
    bubbles = grouped_bubbles(hh_decadal)
    ax.scatter(
        bubbles["Flood"],
        bubbles["All adaptive"],
        s=160 + 100 * bubbles["Decade_count"],
        color=COLORS["Huanghuai"],
        alpha=0.78,
        edgecolor="white",
        linewidth=1.4,
        zorder=3,
    )
    for _, row in bubbles.iterrows():
        if row["Decade_count"] >= 2:
            ax.text(
                row["Flood"],
                row["All adaptive"],
                str(int(row["Decade_count"])),
                ha="center",
                va="center",
                fontsize=20,
                color="white",
                fontweight="bold",
            )

    x_grid = np.linspace(hh_decadal["Flood"].min(), hh_decadal["Flood"].max(), 150)
    prediction_data = pd.DataFrame(
        {
            "const": 1.0,
            "Flood": x_grid,
        }
    )
    predicted = decadal_fit.get_prediction(
        prediction_data[design_columns]
    ).summary_frame(alpha=ALPHA)
    ax.plot(
        x_grid,
        predicted["mean"],
        color="#6E2433",
        linewidth=3.0,
        label="Poisson regression fit",
    )
    ax.fill_between(
        x_grid,
        predicted["mean_ci_lower"],
        predicted["mean_ci_upper"],
        color="#B76B78",
        alpha=0.22,
        label="95% CI",
    )
    ax.set_xlabel("Huanghuai flood region-year\nrecords/decade")
    ax.set_ylabel("Documented adaptive-maintenance\ninterventions/decade")
    ax.grid(color="#E5E5E5", linewidth=1.1)
    add_panel_title(ax, "c", "Huanghuai decadal comparison")
    ax.legend(loc="upper left", frameon=False)

    # ------------------------------------------------------------------ panel d
    ax = fig.add_subplot(grid[1, 1])
    sensitivity_order = [
        "All adaptive",
        "Spline time control (HAC)",
        "Implemented only",
        "No Yellow River involvement",
        "Reactive component present",
        "Proactive component present",
        "Ming only",
        "Qing only",
    ]
    sensitivity_labels = {
        "All adaptive": "All adaptive",
        "Spline time control (HAC)": "Spline + HAC",
        "Implemented only": "Implemented",
        "No Yellow River involvement": "No Yellow River",
        "Reactive component present": "Reactive",
        "Proactive component present": "Proactive",
        "Ming only": "Ming",
        "Qing only": "Qing",
    }
    plotted = sensitivity.loc[
        sensitivity["Hazard"].eq("Flood")
        & sensitivity["Timing"].eq("Same year")
        & sensitivity["Specification"].isin(sensitivity_order)
    ].copy()
    y_values = np.arange(len(sensitivity_order))[::-1]
    for y, specification in zip(y_values, sensitivity_order):
        row = plotted.loc[plotted["Specification"].eq(specification)].iloc[0]
        marker = "D" if specification == "All adaptive" else "o"
        color = COLORS["Huanghuai"] if specification == "All adaptive" else COLORS["Flood"]
        ax.errorbar(
            row["IRR"],
            y,
            xerr=[
                [row["IRR"] - row["CI_low"]],
                [row["CI_high"] - row["IRR"]],
            ],
            fmt=marker,
            markersize=10.0,
            color=color,
            ecolor=color,
            elinewidth=2.0,
            capsize=4.0,
            markerfacecolor=color,
            zorder=3,
        )
    ax.axvline(1.0, color="#777777", linestyle="--", linewidth=1.8)
    ax.set_yticks(y_values)
    ax.set_yticklabels([sensitivity_labels[item] for item in sensitivity_order])
    ax.set_xscale("log")
    ax.set_xticks([0.5, 1, 2, 4, 8])
    ax.set_xticklabels(["0.5", "1", "2", "4", "8"])
    # Include the complete confidence interval, including the Ming estimate.
    upper_limit = max(8.0, float(plotted["CI_high"].max()) * 1.08)
    lower_limit = min(0.5, float(plotted["CI_low"].min()) / 1.08)
    ax.set_xlim(lower_limit, upper_limit)
    ax.set_xlabel("Flood IRR (95% CI)")
    ax.grid(axis="x", color="#E5E5E5", linewidth=1.1)
    add_panel_title(ax, "d", "Huanghuai same-year sensitivity analyses")

    fig.savefig(OUTPUT_DIR / "Figure5.png", dpi=400, bbox_inches="tight")
    fig.savefig(OUTPUT_DIR / "Figure5.pdf", bbox_inches="tight")
    fig.savefig(
        OUTPUT_DIR / "Figure5.tiff",
        dpi=600,
        bbox_inches="tight",
        pil_kwargs={"compression": "tiff_lzw"},
    )
    plt.close(fig)


# =============================================================================
# 8. Save results and caption
# =============================================================================

CAPTION = """Fig. 5. Temporal associations between hydroclimatic extremes and documented major adaptive-maintenance interventions along the Beijing–Hangzhou Grand Canal, 1368–1911. (a) Annual timing of extreme floods, extreme droughts, reactive-restoration interventions, proactive-adjustment interventions, and interventions containing both components in the Hebei, Huanghuai, and Huainan regions. Vertical ticks mark regional flood and drought years; maintenance-symbol size increases with the number of distinct interventions documented in the same region and year. The dashed line marks the Ming–Qing boundary in 1644. (b) Incidence-rate ratios (IRRs) and 95% confidence intervals from annual Poisson pseudo-maximum-likelihood models including same-year and previous-year flood and drought terms and calendar-decade fixed effects, with standard errors clustered by calendar decade. Circles denote same-year co-occurrence and squares denote associations between an extreme event and maintenance in the following year. Filled symbols indicate Holm-adjusted P < 0.05 across the 16 displayed coefficients. At the whole-corridor scale, each hazard coefficient represents one additional affected region in a year; regional hazard indicators are binary. Estimates are conditional on decades containing at least one documented intervention. (c) Descriptive Huanghuai comparison for the 54 complete, nonoverlapping decades from 1370–1379 through 1900–1909. Bubble area and internal numerals indicate the number of decades sharing the same flood-frequency and maintenance-count coordinates. The line shows the Poisson regression fitted mean and its 95% confidence band. (d) Sensitivity estimates for the Huanghuai same-year flood association under an all-years spline time control with heteroskedasticity- and autocorrelation-consistent standard errors, restriction to documented implementation, exclusion of interventions with Yellow River involvement, reactive- and proactive-component definitions, and separate Ming and Qing analyses. Mixed events were included once in each of the two separate component-present models because they contain both components; the two outcomes therefore overlap and were not summed. Horizontal lines indicate 95% confidence intervals. Component- and dynasty-specific estimates are exploratory. Same-year estimates indicate temporal co-occurrence and do not establish within-year ordering or causality."""


def save_outputs(
    events: pd.DataFrame,
    annual: pd.DataFrame,
    decadal: pd.DataFrame,
    primary: pd.DataFrame,
    sensitivity: pd.DataFrame,
    decadal_summary: dict,
) -> None:
    annual.to_csv(
        OUTPUT_DIR / "annual_analysis_counts.csv", index=False, encoding="utf-8-sig"
    )
    decadal.to_csv(
        OUTPUT_DIR / "decadal_analysis_counts.csv", index=False, encoding="utf-8-sig"
    )
    primary.to_csv(
        OUTPUT_DIR / "annual_primary_results.csv", index=False, encoding="utf-8-sig"
    )
    sensitivity.to_csv(
        OUTPUT_DIR / "huanghuai_sensitivity_results.csv",
        index=False,
        encoding="utf-8-sig",
    )

    primary.to_csv(OUTPUT_DIR / "Table_S5_primary_annual_models.csv", index=False)
    retained = sensitivity.loc[sensitivity.Hazard.eq("Flood") & sensitivity.Timing.eq("Same year")].copy()
    order = ["All adaptive","Spline time control (HAC)","Implemented only","No Yellow River involvement","Reactive component present","Proactive component present","Ming only","Qing only"]
    retained["Specification"] = pd.Categorical(retained.Specification,categories=order,ordered=True)
    retained = retained.sort_values("Specification")
    retained["P_adjustment"] = "None; alternative specifications are exploratory"
    retained.to_csv(OUTPUT_DIR / "Table_S6_retained_sensitivity.csv", index=False)

    pd.DataFrame([decadal_summary]).to_csv(
        OUTPUT_DIR / "huanghuai_decadal_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    (OUTPUT_DIR / "Figure5_caption.txt").write_text(CAPTION, encoding="utf-8")

    significant = primary.loc[primary["Holm_significant"]].sort_values("P_Holm")
    lines = [
        "FIGURE 5 ANALYSIS SUMMARY",
        f"Final included maintenance events: {events['Event_ID'].nunique()}",
        f"Reactive restoration: {(events['Mode'] == 'Reactive restoration').sum()}",
        f"Proactive adjustment: {(events['Mode'] == 'Proactive adjustment').sum()}",
        f"Mixed: {(events['Mode'] == 'Mixed').sum()}",
        "",
        "Holm-significant annual coefficients (16-test family):",
    ]
    for _, row in significant.iterrows():
        lines.append(
            f"- {row['Scale']}, {row['Hazard']}, {row['Timing']}: "
            f"IRR={row['IRR']:.3f}, 95% CI={row['CI_low']:.3f}–"
            f"{row['CI_high']:.3f}, raw P={row['P_raw']:.6f}, "
            f"Holm P={row['P_Holm']:.6f}."
        )
    lines.extend(
        [
            "",
            "Interpretation: same-year coefficients measure co-occurrence. "
            "Following-year coefficients provide temporal ordering but do not establish causality.",
            "For component-specific sensitivity models, Mixed events enter both the reactive-present and proactive-present models once; the two overlapping outcomes are analysed separately and are not summed.",
        ]
    )
    (OUTPUT_DIR / "Figure5_summary.txt").write_text(
        "\n".join(lines), encoding="utf-8"
    )


# =============================================================================
# 9. Run
# =============================================================================

def main() -> None:
    configure(globals(), "figure5")
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    check_files()
    events = read_events()
    hazards = read_hazards()
    annual = build_annual_counts(events, hazards)
    decadal = build_decadal_counts(annual)

    primary = run_primary_annual_models(annual)
    sensitivity = run_huanghuai_sensitivity(events, hazards)
    decadal_fit, hh_decadal, design_columns, decadal_summary = (
        fit_huanghuai_decadal(decadal)
    )

    draw_figure(
        annual,
        primary,
        decadal_fit,
        hh_decadal,
        design_columns,
        decadal_summary,
        sensitivity,
    )
    save_outputs(
        events,
        annual,
        decadal,
        primary,
        sensitivity,
        decadal_summary,
    )

    print(f"Analysis complete. Outputs were saved to:\n{OUTPUT_DIR}")
    print("\nHolm-significant annual associations:")
    columns = [
        "Scale",
        "Hazard",
        "Timing",
        "IRR",
        "CI_low",
        "CI_high",
        "P_raw",
        "P_Holm",
    ]
    print(
        primary.loc[primary["Holm_significant"], columns]
        .round(4)
        .to_string(index=False)
    )


if __name__ == "__main__":
    main()
