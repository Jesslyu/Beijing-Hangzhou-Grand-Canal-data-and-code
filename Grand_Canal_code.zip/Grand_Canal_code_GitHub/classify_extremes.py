"""Identify regional extreme years and reproduce Tables S2-S4."""
from __future__ import annotations

import json
import numpy as np
import pandas as pd
from canal_common import REGIONS, parse_options, read_station_grades, read_hazard_data
from figure2 import make_decades, trend


def classify_year(values, sparse):
    values = np.asarray(values, dtype=float)
    valid = values[np.isin(values, [1, 2, 3, 4, 5])]
    n = len(valid)
    if n == 0:
        return 0
    normal = int(np.sum(valid == 3))
    dry, wet = int(np.sum(valid <= 2)), int(np.sum(valid >= 4))
    severe_dry, severe_wet = int(np.sum(valid == 1)), int(np.sum(valid == 5))
    if sparse:
        if normal / n > .25:
            return 0
        abnormal = n - normal
        if dry / abnormal >= .8 and severe_dry >= 2:
            return -1
        if wet / abnormal >= .8 and severe_wet >= 2:
            return 1
    else:
        if dry / n >= .75 and severe_dry / n >= .2:
            return -1
        if wet / n >= .75 and severe_wet / n >= .2:
            return 1
    return 0


def reconstruct(grades):
    rows = []
    for (region, year), group in grades.groupby(["Region", "Year"], sort=True):
        sparse = classify_year(group.Grade, True)
        complete = classify_year(group.Grade, False)
        rows.append({"Region": region, "Year": int(year), "Sparse": sparse,
                     "Complete": complete, "Period_specific": sparse if year <= 1470 else complete})
    return pd.DataFrame(rows)


def agreement_row(data, region):
    true, pred = data.Complete, data.Sparse
    observed = float(true.eq(pred).mean())
    chance = sum(float(true.eq(k).mean())*float(pred.eq(k).mean()) for k in [-1,0,1])
    return {"Region": region, "Region_year_classifications": len(data),
            "Agreement_percent": observed*100, "Cohen_kappa": (observed-chance)/(1-chance)}


def trend_rows(classes):
    rows = []
    for hazard, code in [("Flood", 1), ("Drought", -1)]:
        modes = {}
        for mode in ["Period_specific", "Sparse"]:
            regional = {r: classes.loc[classes.Region.eq(r)].set_index("Year")[mode].eq(code).astype(int) for r in REGIONS}
            modes[mode] = {"Whole corridor": pd.concat(regional, axis=1).sum(axis=1), **regional}
        for scale in ["Whole corridor", *REGIONS]:
            row = {"Region": scale, "Extreme_event": hazard}
            for mode in modes:
                statistics, _ = trend(make_decades(modes[mode][scale]))
                row[mode+"_Sen_slope"] = statistics["sen_slope_per_century"]
                row[mode+"_MK_P"] = statistics["p_mk"]
            rows.append(row)
    return pd.DataFrame(rows)


def dynasty_rows(classes):
    rows = []
    for hazard, code in [("Flood", 1), ("Drought", -1)]:
        row = {"Extreme_event": hazard}
        for dynasty, start, end in [("Ming",1368,1643),("Qing",1644,1911)]:
            period = classes.loc[classes.Year.between(start,end)]
            for mode in ["Period_specific", "Sparse"]:
                count = int(period[mode].eq(code).sum())
                row[f"{dynasty}_{mode}_records"] = count
                row[f"{dynasty}_{mode}_per_decade"] = count/(end-start+1)*10
        rows.append(row)
    return pd.DataFrame(rows)


def main():
    args = parse_options(__doc__, "criteria")
    classes = reconstruct(read_station_grades(args.data_dir))
    published = read_hazard_data(args.data_dir)
    published["Published"] = published.Flood-published.Drought
    comparison = classes.merge(published[["Region","Year","Published"]], on=["Region","Year"], validate="one_to_one")
    if not comparison.Period_specific.eq(comparison.Published).all():
        raise ValueError("Reconstructed labels do not match the public extreme-year files")
    later = classes.loc[classes.Year.ge(1471)]
    agreement = pd.DataFrame([agreement_row(later.loc[later.Region.eq(r)],r) for r in REGIONS]+[agreement_row(later,"Pooled regions")])
    agreement.to_csv(args.output_dir/"Table_S2_criterion_agreement.csv",index=False)
    trend_rows(classes).to_csv(args.output_dir/"Table_S3_uniform_criterion_trends.csv",index=False)
    dynasty_rows(classes).to_csv(args.output_dir/"Table_S4_dynasty_frequencies.csv",index=False)
    classes.to_csv(args.output_dir/"regional_criterion_classifications.csv",index=False)
    first50 = classes.loc[classes.Year.between(1471,1520)]
    first50_summary = {"period":"1471-1520", "agreement_percent":float(first50.Complete.eq(first50.Sparse).mean()*100),
                       "complete_criterion_extreme_records":int(first50.Complete.ne(0).sum()),
                       "sparse_criterion_extreme_records":int(first50.Sparse.ne(0).sum())}
    (args.output_dir/"first_50_years_comparison.json").write_text(json.dumps(first50_summary,indent=2),encoding="utf-8")
    print(agreement.to_string(index=False))
    print(f"Criteria results saved to {args.output_dir}")


if __name__ == "__main__":
    main()
