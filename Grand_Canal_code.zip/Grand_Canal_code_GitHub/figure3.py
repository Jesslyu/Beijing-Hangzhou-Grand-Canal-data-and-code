"""Revised Figure 3 using the updated annual grain-transport files.

Design:
1. Annual records are plotted as points.
2. Lines join consecutive observed years only and break at every missing year.
3. No temporal interpolation, long-term fitted curve, Pettitt test, or phase split.
4. Pressure thresholds use the 54 complete decades from 1370--1909.
   They are applied to the observed Ming and Qing records.
5. Panel c compares decade-level median transport volume across pressure classes.
6. Panel d compares within-decade variability, measured as the sample
   coefficient of variation (CV = SD / mean),
   using only decades with at least three observed transport years.

Panels c and d are descriptive: every small point represents one decade, and
Ming and Qing records are shown separately. Missing years are never coded as zero.
"""

from __future__ import annotations

from canal_common import configure, default_data_dir, default_output_dir, read_transport, read_hazard_data

import os
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle
import numpy as np
import pandas as pd


# ============================================================================
# 0. Paths and settings
# ============================================================================

TRANSPORT_DIR = default_data_dir()
MING_FILE = TRANSPORT_DIR / "caoyun_ming.xlsx"
QING_FILE = TRANSPORT_DIR / "caoyun_qing.xlsx"

HAZARD_DIR = default_data_dir()
HAZARD_FILES = {}

OUTDIR = default_output_dir("figure3")

MING_SPAN = (1411, 1626)
QING_SPAN = (1724, 1849)
MING_COLOR = "#3D8DBD"
QING_COLOR = "#D28A3C"
PRESSURE_COLORS = {
    "Low": "#DCE9F5",
    "Moderate": "#7FAEDB",
    "High": "#235A91",
}

plt.rcParams.update(
    {
        "font.family": "Arial",
        "font.size": 22,
        "axes.titlesize": 24,
        "axes.labelsize": 23,
        "xtick.labelsize": 21,
        "ytick.labelsize": 21,
        "legend.fontsize": 20,
        "axes.linewidth": 1.0,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "mathtext.fontset": "custom",
        "mathtext.rm": "Arial",
        "mathtext.bf": "Arial:bold",
    }
)


# ============================================================================
# 1. Data reading
# ============================================================================

def read_annual_transport(path, expected_n, expected_span):
    return read_transport(path, expected_n, expected_span)


def read_hydroclimatic_pressure():
    """Terciles are based on the 54 complete calendar decades, 1370-1909."""
    regional=read_hazard_data(HAZARD_DIR)
    annual=regional.groupby("Year",as_index=False)[["Flood","Drought"]].sum()
    annual["Combined"]=annual.Flood+annual.Drought
    annual["Decade"]=annual.Year//10*10
    decadal=annual.groupby("Decade",as_index=False)[["Flood","Drought","Combined"]].sum()
    reference=decadal.loc[decadal.Decade.between(1370,1900)]
    if len(reference)!=54:
        raise ValueError("Expected 54 complete decades for pressure classification")
    q1,q2=reference.Combined.quantile([1/3,2/3]).to_numpy(dtype=float)
    decadal["Pressure_class"]=np.select([decadal.Combined<=q1,decadal.Combined<=q2],["Low","Moderate"],default="High")
    return annual,decadal,float(q1),float(q2)


def build_decadal_transport_summary(
    ming: pd.DataFrame,
    qing: pd.DataFrame,
    decadal_pressure: pd.DataFrame,
) -> pd.DataFrame:
    """Create one row per observed decade for level and variability panels."""

    transport = pd.concat(
        [ming.assign(Dynasty="Ming"), qing.assign(Dynasty="Qing")],
        ignore_index=True,
    )
    transport["Decade"] = transport["Year"] // 10 * 10
    summary = (
        transport.groupby(["Dynasty", "Decade"], as_index=False)
        .agg(
            Observed_years=("Volume", "size"),
            Median_volume=("Volume", "median"),
            Mean_volume=("Volume", "mean"),
            SD_volume=("Volume", "std"),
            First_observed_year=("Year", "min"),
            Last_observed_year=("Year", "max"),
        )
        .merge(
            decadal_pressure[
                ["Decade", "Flood", "Drought", "Combined", "Pressure_class"]
            ],
            on="Decade",
            how="left",
            validate="many_to_one",
        )
    )
    summary["Pressure_class"] = pd.Categorical(
        summary["Pressure_class"],
        categories=["Low", "Moderate", "High"],
        ordered=True,
    )
    summary["CV_volume"] = summary["SD_volume"] / summary["Mean_volume"]
    summary["Variability_eligible"] = summary["Observed_years"] >= 3
    return summary.sort_values(["Dynasty", "Decade"]).reset_index(drop=True)


def build_pressure_class_summary(decadal: pd.DataFrame) -> pd.DataFrame:
    """Summarize the decade-level points shown in panels c and d."""

    rows = []
    for dynasty in ["Ming", "Qing"]:
        for pressure_class in ["Low", "Moderate", "High"]:
            group = decadal[
                (decadal["Dynasty"] == dynasty)
                & (decadal["Pressure_class"] == pressure_class)
            ]
            variability = group[group["Variability_eligible"]]
            rows.append(
                {
                    "Dynasty": dynasty,
                    "Pressure_class": pressure_class,
                    "N_decades_level": len(group),
                    "Median_of_decadal_medians": group["Median_volume"].median(),
                    "IQR_low_decadal_median": group["Median_volume"].quantile(0.25),
                    "IQR_high_decadal_median": group["Median_volume"].quantile(0.75),
                    "N_decades_variability": len(variability),
                    "Median_CV_volume": variability["CV_volume"].median(),
                    "IQR_low_CV_volume": variability["CV_volume"].quantile(0.25),
                    "IQR_high_CV_volume": variability["CV_volume"].quantile(0.75),
                }
            )
    return pd.DataFrame(rows)


# ============================================================================
# 2. Plotting helpers
# ============================================================================

def add_pressure_track(
    ax: plt.Axes,
    decadal_pressure: pd.DataFrame,
    start: int,
    end: int,
    data_max: float,
) -> None:
    strip_bottom = data_max * 1.08
    strip_height = data_max * 0.055
    subset = decadal_pressure[
        (decadal_pressure["Decade"] + 9 >= start)
        & (decadal_pressure["Decade"] <= end)
    ]

    for row in subset.itertuples(index=False):
        x0 = max(int(row.Decade), start)
        x1 = min(int(row.Decade) + 10, end + 1)
        ax.add_patch(
            Rectangle(
                (x0, strip_bottom),
                x1 - x0,
                strip_height,
                facecolor=PRESSURE_COLORS[row.Pressure_class],
                edgecolor="white",
                linewidth=0.45,
                zorder=1,
            )
        )

def plot_annual_panel(
    ax: plt.Axes,
    data: pd.DataFrame,
    decadal_pressure: pd.DataFrame,
    span: tuple[int, int],
    color: str,
    panel_letter: str,
    dynasty: str,
) -> None:
    """Plot points and connect only consecutive observed calendar years."""

    start, end = span
    complete_year_index = pd.Index(range(start, end + 1), name="Year")
    complete = data.set_index("Year").reindex(complete_year_index)

    # NaN values automatically break the line wherever a calendar year is absent.
    ax.plot(
        complete.index,
        complete["Volume"],
        color=color,
        linewidth=1.15,
        alpha=0.78,
        zorder=2,
    )
    ax.scatter(
        data["Year"],
        data["Volume"],
        s=31,
        facecolor=color,
        edgecolor="white",
        linewidth=0.45,
        zorder=3,
    )

    maximum = float(data["Volume"].max())
    add_pressure_track(ax, decadal_pressure, start, end, maximum)

    ax.set_xlim(start - 3, end + 3)
    ax.set_ylim(0, maximum * 1.20)
    ax.set_ylabel("Recorded grain-transport\nvolume\n($10^4$ dan)")
    ax.set_title(
        rf"$\bf{{{panel_letter}}}$  {dynasty}: annual records",
        loc="left",
        pad=10,
    )
    ax.set_xlabel("Year")
    ax.grid(axis="y", color="#D9D9D9", linewidth=0.7, alpha=0.75)
    ax.spines[["top", "right"]].set_visible(False)


def plot_pressure_class_panel(
    ax: plt.Axes,
    decadal: pd.DataFrame,
    metric: str,
    panel_letter: str,
    title: str,
    ylabel: str,
    variability_panel: bool = False,
) -> None:
    """Plot dynasty-specific decade points and descriptive median/IQR summaries."""

    classes = ["Low", "Moderate", "High"]
    x_positions = np.arange(len(classes), dtype=float)
    dynasty_settings = {
        "Ming": {"offset": -0.16, "color": MING_COLOR, "marker": "o"},
        "Qing": {"offset": 0.16, "color": QING_COLOR, "marker": "^"},
    }

    plot_data = decadal.copy()
    if variability_panel:
        plot_data = plot_data[plot_data["Variability_eligible"]].copy()

    for class_index, pressure_class in enumerate(classes):
        for dynasty, settings in dynasty_settings.items():
            group = plot_data[
                (plot_data["Dynasty"] == dynasty)
                & (plot_data["Pressure_class"] == pressure_class)
            ].sort_values("Decade")
            if group.empty:
                continue

            center = x_positions[class_index] + settings["offset"]
            jitter = (
                np.linspace(-0.055, 0.055, len(group))
                if len(group) > 1
                else np.array([0.0])
            )
            for point_x, row in zip(center + jitter, group.itertuples(index=False)):
                reliable_fill = variability_panel or row.Observed_years >= 3
                ax.scatter(
                    point_x,
                    getattr(row, metric),
                    s=78,
                    marker=settings["marker"],
                    facecolor=settings["color"] if reliable_fill else "white",
                    edgecolor=settings["color"],
                    linewidth=1.2,
                    alpha=0.88,
                    zorder=3,
                )

            values = group[metric].dropna()
            group_median = float(values.median())
            q_low = float(values.quantile(0.25))
            q_high = float(values.quantile(0.75))
            if len(values) >= 3:
                ax.vlines(
                    center,
                    q_low,
                    q_high,
                    color=settings["color"],
                    linewidth=5.0,
                    alpha=0.58,
                    zorder=2,
                )
            ax.scatter(
                center,
                group_median,
                s=155,
                marker="D",
                facecolor=settings["color"],
                edgecolor="white",
                linewidth=1.0,
                zorder=4,
            )
    ax.set_xticks(x_positions)
    ax.set_xticklabels(["Low", "Moderate", "High"])
    ax.set_xlim(-0.55, 2.55)
    metric_maximum = float(plot_data[metric].max())
    ax.set_ylim(0, metric_maximum * 1.20)
    ax.set_xlabel("Hydroclimatic pressure")
    ax.set_ylabel(ylabel)
    ax.set_title(rf"$\bf{{{panel_letter}}}$  {title}", loc="left", pad=10)
    ax.grid(axis="y", color="#E1E1E1", linewidth=0.7, alpha=0.8)
    ax.spines[["top", "right"]].set_visible(False)


# ============================================================================
# 3. Build and save figure
# ============================================================================

def main() -> None:
    configure(globals(), "figure3")
    OUTDIR.mkdir(parents=True, exist_ok=True)

    ming = read_annual_transport(MING_FILE, 122, MING_SPAN)
    qing = read_annual_transport(QING_FILE, 50, QING_SPAN)
    _, decadal_pressure, q1, q2 = read_hydroclimatic_pressure()
    decadal_transport = build_decadal_transport_summary(
        ming, qing, decadal_pressure
    )
    pressure_class_summary = build_pressure_class_summary(decadal_transport)

    fig = plt.figure(figsize=(17.0, 12.8))
    grid = fig.add_gridspec(
        2,
        2,
        height_ratios=[1.0, 1.0],
        hspace=0.42,
        wspace=0.50,
    )

    ax_ming = fig.add_subplot(grid[0, 0])
    ax_qing = fig.add_subplot(grid[0, 1])
    ax_level = fig.add_subplot(grid[1, 0])
    ax_variability = fig.add_subplot(grid[1, 1])
    plot_annual_panel(
        ax_ming,
        ming,
        decadal_pressure,
        MING_SPAN,
        MING_COLOR,
        "a",
        "Ming",
    )
    plot_annual_panel(
        ax_qing,
        qing,
        decadal_pressure,
        QING_SPAN,
        QING_COLOR,
        "b",
        "Qing",
    )
    plot_pressure_class_panel(
        ax_level,
        decadal_transport,
        "Median_volume",
        "c",
        "Decadal transport volume by pressure class",
        "Median recorded\ntransport volume\n($10^4$ dan)",
    )
    plot_pressure_class_panel(
        ax_variability,
        decadal_transport,
        "CV_volume",
        "d",
        "Within-decade variability by pressure class",
        "Within-decade CV of\nrecorded transport\nvolume",
        variability_panel=True,
    )

    record_legend = [
        Line2D(
            [],
            [],
            color="#666666",
            marker="o",
            markerfacecolor="#666666",
            linewidth=1.15,
            markersize=5.5,
            label="Annual records",
        ),
        Line2D(
            [],
            [],
            color=MING_COLOR,
            marker="o",
            linestyle="none",
            markersize=9,
            label="Ming decades",
        ),
        Line2D(
            [],
            [],
            color=QING_COLOR,
            marker="^",
            linestyle="none",
            markersize=9,
            label="Qing decades",
        ),
        Line2D(
            [],
            [],
            color="#777777",
            marker="D",
            markerfacecolor="#777777",
            linewidth=5.0,
            markersize=8,
            label="Median / IQR",
        ),
        Patch(facecolor=PRESSURE_COLORS["Low"], label="Low"),
        Patch(facecolor=PRESSURE_COLORS["Moderate"], label="Moderate"),
        Patch(facecolor=PRESSURE_COLORS["High"], label="High"),
    ]
    fig.legend(
        handles=record_legend,
        loc="lower center",
        bbox_to_anchor=(0.5, 0.012),
        ncol=7,
        frameon=False,
        columnspacing=0.55,
        handlelength=1.5,
        fontsize=23,
    )

    fig.subplots_adjust(left=0.115, right=0.985, top=0.985, bottom=0.180)

    save_options = {
        "facecolor": "white",
        "bbox_inches": "tight",
        "pad_inches": 0.08,
    }
    fig.savefig(
        OUTDIR / "Figure3_annual_records_and_pressure_classes.png",
        dpi=600,
        **save_options,
    )
    fig.savefig(
        OUTDIR / "Figure3_annual_records_and_pressure_classes.pdf",
        **save_options,
    )
    fig.savefig(
        OUTDIR / "Figure3_annual_records_and_pressure_classes.tiff",
        dpi=600,
        pil_kwargs={"compression": "tiff_lzw"},
        **save_options,
    )
    plt.close(fig)

    decadal_transport.to_csv(
        OUTDIR / "Figure3_decadal_transport_by_pressure_class.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pressure_class_summary.to_csv(
        OUTDIR / "Figure3_pressure_class_summary_by_dynasty.csv",
        index=False,
        encoding="utf-8-sig",
    )
    decadal_pressure.to_csv(
        OUTDIR / "Figure3_decadal_hydroclimatic_pressure.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print(pressure_class_summary.to_string(index=False))
    print(f"Pressure terciles: q1 = {q1:.3f}, q2 = {q2:.3f}")
    print(f"Results saved to: {OUTDIR}")


if __name__ == "__main__":
    main()
