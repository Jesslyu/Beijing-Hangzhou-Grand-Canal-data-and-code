"""Autocorrelation diagnostics for the eight Figure 2 decadal series.

Put this script beside the three public regional extreme-year Excel files and run it.
Dependencies: numpy pandas openpyxl. statsmodels is optional (used if installed).
Outputs: summary.csv, decadal_residuals.csv, and method_notes.txt (UTF-8 BOM CSVs).
The CSV tables can be opened directly in Excel. Inputs are never modified.
"""

from canal_common import default_data_dir, default_output_dir, read_extreme_years, parse_options
from pathlib import Path
from math import erfc, sqrt, exp, pi
import argparse
import json
import numpy as np
import pandas as pd

REGIONS = {"Hebei":"HEBEI_DRY_WET_TABLE.xlsx", "Huanghuai":"HUANGHUAI_DRY_WET_TABLE.xlsx", "Huainan":"HUAINAN_DRY_WET_TABLE.xlsx"}
START, END = 1368, 1911

NOTES = """Autocorrelation diagnostics for Figure 2
1. Classification: flood=1, drought=-1, non-extreme=0. Each input must contain
   every year from 1368 through 1911 once, with no missing classifications.
2. Whole-corridor counts sum region-year occurrences; simultaneous occurrences
   in different regions are retained. Missing years are not treated as zero.
3. Trend/detrending diagnostics use 54 full decades, 1370-1379 through 1900-1909.
   Partial decades 1368-1369 and 1910-1911 are excluded. No smoothing is used.
4. raw_acf1 and residual_acf1 are pandas lag-1 Pearson autocorrelations, for
   the decadal diagnostic series. Lag 1 represents 10 years.
5. OLS of raw counts on an intercept and calendar time is used ONLY to remove
   a linear trend before diagnostics. It does not replace the Sen/MK analysis.
6. residual_lb5_Q and residual_lb5_p are the Ljung-Box test jointly across lags
   1 through 5 (10-50 years). Null: residual autocorrelations at these lags are zero.
   Q uses demeaned, biased ACF estimates, not the lag-1 Pearson column above.
7. To reproduce the earlier statsmodels call, model_df=0; the approximate
   reference distribution is chi-square with 5 degrees of freedom. This is an
   exploratory residual diagnostic, not an exact finite-sample test after detrending.
8. P>=0.05 means no significant autocorrelation was detected by this test; it
   does not prove independence, nor correct the standard MK P value.
9. Eight sequences are assessed separately, without multiple-testing adjustment.
   All calculations and CSVs retain full precision; display may use four decimals.
"""


def read_annual(path):
    return read_extreme_years(path)


def ljung_box5(residual):
    """Reproduce acorr_ljungbox(residual, lags=[5], model_df=0)."""
    z = np.asarray(residual, dtype=float)
    z = z - z.mean()
    denominator = np.dot(z, z)
    if denominator <= 1e-24:
        return np.nan, np.nan
    try:
        from statsmodels.stats.diagnostic import acorr_ljungbox
    except ImportError:
        # Equivalent calculation without scipy/statsmodels; fixed lag count 5.
        n = len(z)
        rho = np.array([np.dot(z[k:], z[:-k]) / denominator for k in range(1, 6)])
        q = float(n * (n + 2) * np.sum(rho**2 / (n - np.arange(1, 6))))
        x = q / 2
        # Chi-square(5) survival from half-integer incomplete-gamma recurrence.
        p = erfc(sqrt(x)) + exp(-x) / sqrt(pi) * (2 * sqrt(x) + 4/3 * x**1.5)
        return q, min(1.0, max(0.0, p))
    result = acorr_ljungbox(z, lags=[5], model_df=0, return_df=True)
    return float(result.lb_stat.iloc[0]), float(result.lb_pvalue.iloc[0])


def diagnose(data_dir):
    annual = {r: read_annual(data_dir / cn) for r, cn in REGIONS.items()}
    summary, details = [], []
    for hazard, code in [("Flood", 1), ("Drought", -1)]:
        events = {r: s.eq(code).astype(int) for r, s in annual.items()}
        events = {"Whole corridor": pd.concat(events, axis=1).sum(axis=1), **events}
        for region, event in events.items():
            group = event.groupby(event.index // 10 * 10)
            all_counts = group.sum()
            counts = all_counts.loc[group.size().eq(10)]
            if len(counts) != 54 or not np.all(np.diff(counts.index) == 10):
                raise ValueError("Expected 54 consecutive complete decades, 1370-1909.")
            y = counts.to_numpy(dtype=float)
            years = counts.index.to_numpy(dtype=float)
            x = (years - years.mean()) / 100
            design = np.column_stack([np.ones(len(x)), x])
            coef = np.linalg.lstsq(design, y, rcond=None)[0]
            fitted = design @ coef
            residual = y - fitted
            constant = np.ptp(y) == 0
            raw_r = float(pd.Series(y).autocorr(1)) if not constant else np.nan
            res_r = float(pd.Series(residual).autocorr(1)) if np.std(residual) > 1e-12 else np.nan
            q, p = ljung_box5(residual)
            flag = "Not testable" if not np.isfinite(p) else ("Detected" if p < .05 else "Not detected")
            summary.append(dict(region=region, hazard=hazard, n_decades=len(y),
                                first_year=1370, last_year=1909, raw_acf1=raw_r,
                                residual_acf1=res_r, residual_lb5_Q=q, residual_lb5_p=p,
                                lb_lags=5, lb_df=5, significant_autocorrelation=flag))
            details.extend(dict(region=region, hazard=hazard, decade=int(t), count=int(v),
                                fitted_ols=float(f), residual=float(e))
                           for t, v, f, e in zip(years, y, fitted, residual))
    return pd.DataFrame(summary), pd.DataFrame(details)


def main():
    args = parse_options(__doc__, "autocorrelation")
    summary, detail = diagnose(args.data_dir)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(args.output_dir / "Table_S1_autocorrelation.csv", index=False, encoding="utf-8-sig")
    detail.to_csv(args.output_dir / "decadal_residuals.csv", index=False, encoding="utf-8-sig")
    (args.output_dir / "method_notes.txt").write_text(NOTES, encoding="utf-8")
    print(summary.to_string(index=False, float_format=lambda v: f"{v:.4f}"))
    print(f"Tables saved to: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
